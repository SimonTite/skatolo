import os.path
import cherrypy

class Root:
    @cherrypy.expose
    def index(self):
        return file('auth.html').read()
    
class Hello:
    @cherrypy.expose
    def default(self, username):
        return "Hello %s" % username

if __name__ == '__main__':
    r = Root()
    r.hello = Hello()
    current_dir = os.path.abspath(os.path.dirname(__file__))

    def get_credentials():
        return {'test': 'test'}
    
    conf = {'/hello': {'tools.digest_auth.on': True,
                       'tools.digest_auth.realm': 'localhost',
                       'tools.digest_auth.users': get_credentials},
            '/MochiKit': { 'tools.staticdir.on': True,
                           'tools.staticdir.dir': os.path.join(current_dir, 'MochiKit')}}

    cherrypy.quickstart(r, config=conf)
