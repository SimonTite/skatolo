import cherrypy
from cherrypy import tools

class Root:
    @cherrypy.expose
    def index(self):
        return """<html>
<head></head>
<body>
  <form action="hello" method="post">
    <input type="text" name="name" value="" />
  </form>
</body>
</html>
"""
  
    @cherrypy.expose
    @tools.decode(encoding='ISO-8859-1')
    def hello(self, name):
        print type(name)
        return "Hello %s" % (name, )
    
if __name__ == '__main__':
    cherrypy.quickstart(Root(), '/')
