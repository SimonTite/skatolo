import cherrypy
from cherrypy import tools

class Root:
    @cherrypy.expose
    def index(self):
        return """<html>
<head></head>
<body>
  <form action="hello" method="post">
    <input type="text" name="name" value="" />
  </form>
</body>
</html>
"""
  
    @cherrypy.expose
    @tools.encode(encoding='ISO-88510-15')
    def hello(self, name):
        return "Hello %s" % name
    
if __name__ == '__main__':
    cherrypy.quickstart(Root(), '/')
