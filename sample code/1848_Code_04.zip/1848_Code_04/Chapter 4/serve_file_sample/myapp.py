import os.path
import cherrypy
from cherrypy.lib.static import serve_file

class Root:
    @cherrypy.expose
    def feed(self, name):
        accepts = cherrypy.request.headers.elements('Accept')
        for accept in accepts:
            if accept.value == 'application/atom+xml':
                cherrypy.log('Using Atom')
                return serve_file(os.path.join(current_dir, 'feeds', '%s.atom' % name),
                                  content_type='application/atom+xml')

        cherrypy.log('Using RSS')
        # Not Atom accepted? Well then send RSS instead...
        return serve_file(os.path.join(current_dir, 'feeds', '%s.rss' % name),
                          content_type='application/xml')
    
if __name__ == '__main__':
    current_dir = os.path.dirname(os.path.abspath(__file__))
    cherrypy.config.update({'environment': 'production',
                            'log.screen': True})
    cherrypy.quickstart(Root(), '/')
