import cherrypy
from cherrypy import tools

class Root:
    @cherrypy.expose
    def index(self):
        return """<html>
<head></head>
<body>
  <form action="hello" method="post">
    <input type="text" name="name" value="" />
  </form>
</body>
</html>
"""
  
    @cherrypy.expose
    def hello(self, name):
        return "Hello %s" % name
    
if __name__ == '__main__':
    conf = {'/': {'tools.etags.on': True,
                  'tools.etags.autotags': True}}
    cherrypy.quickstart(Root(), '/', config=conf)
