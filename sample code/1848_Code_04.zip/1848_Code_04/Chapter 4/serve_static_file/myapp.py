import cherrypy

class MyApp:
    @cherrypy.expose
    def index(self):
        return """<html>
<head>
  <title>My application</title>
  <link rel="stylesheet" href="css/style.css" type="text/css"></link>
</head>
<html>
<body>
  Hello to you.
</body>
</html>"""

if __name__ == '__main__':
    import os.path
    current_dir = os.path.dirname(os.path.abspath(__file__))
    cherrypy.config.update({'environment': 'production',
                            'log.screen': True})
    conf = {'/': {'tools.staticfile.root': current_dir},
            '/css/style.css': {'tools.staticfile.on': True,
                               'tools.staticfile.filename':
                               'design.css'}}
    cherrypy.quickstart(MyApp(), '/my', config=conf)
