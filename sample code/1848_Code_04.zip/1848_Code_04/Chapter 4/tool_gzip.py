import cherrypy
from cherrypy import tools

class Root:
    @cherrypy.expose
    @tools.gzip()
    def index(self):
        return "this will be compressed"
    
if __name__ == '__main__':
    cherrypy.quickstart(Root(), '/')
