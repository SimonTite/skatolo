import cherrypy
from cherrypy import tools
try:
    from wsgiref.simple_server import make_server
except ImportError:
    print "This example requires wsgiref: easy_install -U wsgiref"
    import sys
    sys.exit()
    
try:
    from flup.middleware.gzip import GzipMiddleware
except ImportError:
    print "This example requires flup: easy_install -U flup"
    import sys
    sys.exit()

class Root:
    @cherrypy.expose
    @tools.response_headers(headers=[('Content-Language', 'en-GB')])
    def index(self):
        return "Hello world!"
    
if __name__ == '__main__':
    wsgi_app = cherrypy.Application(Root(), script_name="/")
    cherrypy.engine.start(blocking=False)
    httpd = make_server('localhost', 8080, GzipMiddleware(wsgi_app))
    print "HTTP Serving HTTP on http://localhost:8080/"
    httpd.serve_forever()
