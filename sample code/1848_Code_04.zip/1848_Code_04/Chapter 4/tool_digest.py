import cherrypy

class Root:
    @cherrypy.expose
    def index(self):
        return """<html>
<head></head>
<body>
  <a href="admin">Admin area</a>
</body>
</html>
"""
    
class Admin:
    @cherrypy.expose
    def index(self):
        return "This is a private area"
    
if __name__ == '__main__':
    def get_users():
        return {'test': 'test'}
    
    conf = {'/admin': {'tools.digest_auth.on': True,
                       'tools.digest_auth.realm': 'Some site',
                       'tools.digest_auth.users': get_users}}
    root = Root()
    root.admin = Admin()
    cherrypy.quickstart(root, '/', config=conf)
