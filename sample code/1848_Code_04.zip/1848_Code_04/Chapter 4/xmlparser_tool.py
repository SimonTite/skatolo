import cherrypy
from cherrypy import tools
from cherrypy import Tool
from xml.parsers.expat import ExpatError
from xml.sax._exceptions import SAXParseException

def xmlparse(engine='elementtree', valid_content_types=['text/xml', 'application/xml'], param_name='doc'):
    # Transform the XML document contained in the request body into
    # an instance of the chosen XML engine.
    # Get the mime type of the entity sent by the user-agent
    ct = cherrypy.request.headers.get('Content-Type', None)
    
    # if it is not a mime type we can handle
    # then let's inform the user-agent
    if ct not in valid_content_types:
        raise cherrypy.HTTPError(415, 'Unsupported Media Type')
    
    # CherryPy will set the request.body with a file object
    # where to read the content from
    if hasattr(cherrypy.request.body, 'read'):
        content = cherrypy.request.body.read()
        doc = content
        try:
             if engine == 'elementtree':
                 from elementtree import ElementTree as ETX
                 doc = ETX.fromstring(content)
             elif engine == 'amara':
                 import amara
                 doc = amara.parse(content)
        except (ExpatError, SAXParseException):
             raise cherrypy.HTTPError(400, 'XML document not well-formed')
        # inject the parsed document instance into
        # the request parameters as if it had been
        # a regular URL encoded value
        cherrypy.request.params[param_name] = doc
        
# Create a new Tool and attach it to the default CherryPy toolbox
tools.xml_parse = Tool('before_handler', xmlparse)

class Root:
    @cherrypy.expose
    @tools.xml_parse()
    def echoet(self, doc):
        return doc.find('.//message').text
    
    @cherrypy.expose
    @tools.xml_parse(engine='amara', param_name='d')
    def echoamara(self, d):
        return unicode(d.root.message)
    
if __name__ == '__main__':
    cherrypy.quickstart(Root(), '/')
