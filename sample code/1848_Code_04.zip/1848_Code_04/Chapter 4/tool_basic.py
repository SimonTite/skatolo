import sha
import cherrypy

class Root:
    @cherrypy.expose
    def index(self):
        return """<html>
<head></head>
<body>
  <a href="admin">Admin area</a>
</body>
</html>
"""
    
class Admin:
    @cherrypy.expose
    def index(self):
        return "This is a private area"
    
if __name__ == '__main__':
    def get_users():
        return {'test': sha.new('test').hexdigest()}
    
    def encrypt_pwd(token):
        return sha.new(token).hexdigest()
    
    conf = {'/admin': {'tools.basic_auth.on': True,
                       'tools.basic_auth.realm': 'Some site',
                       'tools.basic_auth.users': get_users,
                       'tools.basic_auth.encrypt': encrypt_pwd}}
    root = Root()
    root.admin = Admin()
    cherrypy.quickstart(root, '/', config=conf)
