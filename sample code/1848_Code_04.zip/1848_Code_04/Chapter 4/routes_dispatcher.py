import cherrypy

class Root:
    def index(self):
        return "Not much to say"
    
    def hello(self, name):
        return "Hello %s" % name

if __name__ == '__main__':
    root = Root()
    # Create an instance of the dispatcher
    d = cherrypy.dispatch.RoutesDispatcher()
    # connect a route that will be handled by the 'index' handler
    d.connect('default_route', '', controller=root)
    # connect a route to the 'hello' handler
    # this will match URIs such as '/say/hello/there'
    # but not '/hello/there'
    d.connect('some_other', 'say/:action/:name',
              controller=root, action='hello')
    # set the dispatcher
    conf = {'/': {'request.dispatch': d}}
    cherrypy.quickstart(root, '/', config=conf)
