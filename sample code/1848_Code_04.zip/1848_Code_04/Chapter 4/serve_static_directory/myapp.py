import cherrypy

class MyApp:
    @cherrypy.expose
    def index(self):
        return """<html>
<head>
  <title>My application</title>
  <link rel="stylesheet" href="static/css/design.css"
   type="text/css"></link>
  <script type="application/javascript"
   src="static/scripts/some.js"></script>
</head>
<html>
<body>
  <a href="feed/app.rss">RSS 2.0 feed</a>
  <a href="feed/app.atom">Atom 1.0 feed</a>
</body>
</html>"""
  
if __name__ == '__main__':
    import os.path
    current_dir = os.path.dirname(os.path.abspath(__file__))
    cherrypy.config.update({'environment': 'production',
                            'log.screen': True})
    conf = {'/': {'tools.staticdir.root': current_dir},
            '/static/css': {'tools.gzip.on': True,
                            'tools.gzip.mime_types':['text/css'],
                            'tools.staticdir.on': True,
                            'tools.staticdir.dir': 'data'},
            '/static/scripts': {'tools.gzip.on': True,
                                'tools.gzip.mime_types': ['application/javascript'],
                                'tools.staticdir.on': True,
                                'tools.staticdir.dir': 'data'},
            '/feed': {'tools.staticdir.on': True,
                      'tools.staticdir.dir': 'feeds',
                      'tools.staticdir.content_types': {'rss':'application/xml',
                                                        'atom': 'application/atom+xml'}}}
    cherrypy.quickstart(MyApp(), '/', config=conf)
