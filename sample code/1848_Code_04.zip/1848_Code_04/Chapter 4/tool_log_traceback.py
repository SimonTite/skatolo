import cherrypy
from cherrypy import tools

class Root:
    @cherrypy.expose
    def index(self):
        raise StandardError, "Some sensible error message here"
    
if __name__ == '__main__':
    # This tool is applied globally to the CherryPy process
    # by using the global cherrypy.config.update method.
    cherrypy.config.update({'global': {'tools.log_tracebacks.on': False}})
    cherrypy.quickstart(Root(), '/')
