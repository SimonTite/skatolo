import cherrypy
from cherrypy import tools

class Root:
    @cherrypy.expose
    def index(self):
        return "This should have been redirected to add the trailing slash"
    
    @cherrypy.expose
    def nothing(self):
        return "This should have NOT been redirected"
    nothing._cp_config = {'tools.trailing_slash.on': False}
    
    @cherrypy.expose
    def extra(self):
        return """This should have been redirected to remove the
trailing slash"""
    extra._cp_config = {'tools.trailing_slash.on': True,
                        'tools.trailing_slash.missing': False,
                        'tools.trailing_slash.extra': True}
    
if __name__ == '__main__':
    cherrypy.quickstart(Root(), '/')
