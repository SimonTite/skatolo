import cherrypy
from cherrypy import tools

class Root:
    @cherrypy.expose
    @tools.ignore_headers(headers=('Accept-Language',))
    def index(self):
        return "Accept-Language: %s" \
                % cherrypy.request.headers.get('Accept-Language',
                                               'none provided')
    @cherrypy.expose
    def other(self):
        return "Accept-Language: %s" % \
               cherrypy.request.headers.get('Accept-Language')
    
if __name__ == '__main__':
    cherrypy.quickstart(Root(), '/')
