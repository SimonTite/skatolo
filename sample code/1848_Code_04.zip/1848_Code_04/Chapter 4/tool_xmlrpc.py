import cherrypy
from cherrypy import _cptools

class Root:
    @cherrypy.expose
    def index(self):
        return "Regular web page handler"
    
class XMLRPCApp(_cptools.XMLRPCController):
    @cherrypy.expose
    def echo(self, message):
        return message
    
if __name__ == '__main__':
    root = Root()
    root.xmlrpc = XMLRPCApp()
    cherrypy.quickstart(root, '/')
