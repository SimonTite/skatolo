import cherrypy
from cherrypy import tools

class Root:
    @cherrypy.expose
    def index(self):
        raise StandardError, "Some sensible error message here"
    
if __name__ == '__main__':
    cherrypy.config.update({'global': {'tools.log_headers.on': True}})
    cherrypy.quickstart(Root(), '/')
