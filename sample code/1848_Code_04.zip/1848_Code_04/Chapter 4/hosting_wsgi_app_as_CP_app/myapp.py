import cherrypy
try:
    from paste.translogger import TransLogger
except ImportError:
    print "This example requires Paste: easy_install -U paste"
    import sys
    sys.exit()

def application(environ, start_response):
    status = '200 OK'
    response_headers = [('Content-type', 'text/plain')]
    start_response(status, response_headers)
    return ['Hello world!\n']

class Root:
    pass

if __name__ == '__main__':
    cherrypy.config.update({'checker.on': False})
    app = TransLogger(application)
    conf = {'/': {'tools.wsgiapp.on': True,
                  'tools.wsgiapp.app': app,
                  'tools.gzip.on': True}}
    cherrypy.tree.mount(Root(), '/', config=conf)
    cherrypy.server.quickstart()
    cherrypy.engine.start()
