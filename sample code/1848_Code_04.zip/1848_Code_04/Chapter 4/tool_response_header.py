import cherrypy
from cherrypy import tools

class Root:
    @cherrypy.expose
    def index(self):
        return "Some text"
    @cherrypy.expose
    
    def other(self):
        return "Some other text"
    
if __name__ == '__main__':
    conf = {'/': {'tools.response_headers.on': True,
                  'tools.response_headers.headers': [('Content-Type',
                                                     'text/plain')]}}
    cherrypy.quickstart(Root(), '/', config=conf)
