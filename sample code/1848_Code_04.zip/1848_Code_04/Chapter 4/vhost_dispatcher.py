import cherrypy

class Site:
    def index(self):
        return "Hello, world"
    index.exposed = True


class Forum:
    def __init__(self, name):
        self.name = name
        
    def index(self):
        return "Welcome on the %s forum" % self.name
    index.exposed = True

if __name__ == '__main__':
    site = Site()
    site.cars = Forum('Cars')
    site.music = Forum('My Music')

    hostmap = {'www.ilovecars.com': '/cars',
               'www.mymusic.com': '/music',}

    cherrypy.config.update({'server.socket_port': 80})
    conf = {'/': {'request.dispatch': cherrypy.dispatch.VirtualHost(**hostmap)}}
    cherrypy.tree.mount(site, config=conf)
    cherrypy.server.quickstart()
    cherrypy.engine.start()
