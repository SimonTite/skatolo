from sqlalchemy import *

engine = create_engine('postgres://test:test@localhost:5432/cdtek', echo=True)
metadata = BoundMetaData(engine)
    
class Artist(object):
    def __init__(self, name):
        self.id = None
        self.name = name
    
class Album(object):
    def __init__(self, title, release_year=0):
        self.id = None
        self.title = title
        self.release_year = release_year

class Song(object):
    def __init__(self, title, position=0):
        self.id = None
        self.title = title
        self.position = position

artist_table = Table('Artist', metadata,
                     Column('id', Integer, primary_key=True),
                     Column('name', String(), unique=True))

song_table = Table('Song', metadata,
                   Column('id', Integer, primary_key=True),
                   Column('title', String()),
                   Column('position', Integer),
                   Column('album_id', Integer,
                          ForeignKey('Album.id')))

album_table = Table('Album', metadata,
                    Column('id', Integer, primary_key=True),
                    Column('title', String()),
                    Column('release_year', Integer),
                    Column('artist_id', Integer,
                           ForeignKey('Artist.id')))


song_mapper = mapper(Song, song_table)
album_mapper = mapper(Album, album_table, properties = {
    'songs': relation(song_mapper, cascade="all, delete-orphan")
    })
artist_mapper = mapper(Artist, artist_table, properties = {
    'albums': relation(album_mapper, 
                       cascade="all, delete-orphan")
    })


def create_tables():
    artist_table.create(checkfirst=True)
    album_table.create(checkfirst=True)
    song_table.create(checkfirst=True)
    
def drop_tables():
    song_table.drop(checkfirst=False)
    album_table.drop(checkfirst=False)
    artist_table.drop(checkfirst=False)

def play():
    session = create_session(bind_to=engine)
    
    jeff_buckley = Artist(name="Jeff Buckley")

    grace = Album(title="Grace", release_year=1994)
    
    dream_brother = Song(title="Dream Brother", position=10)
    mojo_pin = Song(title="Mojo Pin", position=1)
    lilac_wine = Song(title="Lilac Wine", position=4)
    
    grace.songs.append(dream_brother)
    grace.songs.append(mojo_pin)
    grace.songs.append(lilac_wine)
    jeff_buckley.albums.append(grace)
    session.save(jeff_buckley)
    session.flush()


def display_info(artist):
    for album in artist.albums:
        message = """
        %s released %s in %d
        It contains the following songs:\n""" % (artist.name,
                                                 album.title,
                                                 album.release_year)
        for song in album.songs:
            message = message + "       %s\n" % (song.title, )
        print message

if __name__ == '__main__':
    create_tables()

    play()
    session = create_session(bind_to=engine)

    # Retrieve an artist by his name
    buckley = session.query(Artist).get_by(name='Jeff Buckley')
    display_info(buckley)

    # Retrieve songs containing the word 'la' from the given artist
    songs = session.query(Song).select(and_(artist_table.c.name=="Jeff Buckley", song_table.c.title.like("%la%")))
    for song in songs:
        print "  %s" % (song.title,)

    # Retrieve all songs but only display some of them
    # Note that we specify the order by clause at this level
    songs = session.query(Song).select(order_by=[Song.c.position])
    print "Found %d songs, let's show only a few of them:" % (len(songs), )
    for song in songs[1:-1]:
        print "  %s" % (song.title,)

    # Retrieve an album by its ID
    album = session.query(Album).get_by(id=1)
    print album.title

    # Delete the album and all its dependencies
    # since we have specified cascade delete
    session.delete(album)
    session.flush()

    drop_tables()
