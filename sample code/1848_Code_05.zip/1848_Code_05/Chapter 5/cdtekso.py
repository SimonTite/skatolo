from sqlobject import *

# Create a connection to a SQLlite 'in memory' database
sqlhub.processConnection = connectionForURI('sqlite:/:memory:?debug=True')

class Song(SQLObject):
    title = StringCol()
    position = IntCol()
    album = ForeignKey('Album', cascade=True)

class Album(SQLObject):
    title = StringCol()
    release_year = IntCol()
    artist = ForeignKey('Artist', cascade=True)
    songs = MultipleJoin('Song', orderBy="position")

class Artist(SQLObject):
    # Using alternateID will automatically
    # create a byName() method
    name = StringCol(alternateID=True, unique=True)
    albums = MultipleJoin('Album')

def create_tables():
    Album.createTable()
    Song.createTable()
    Artist.createTable()

def drop_tables():
    Song.dropTable()
    Artist.dropTable()
    Album.dropTable()

def play():
    # Create an artist
    jeff_buckley = Artist(name="Jeff Buckley")

    # Create an album for that artist
    grace = Album(title="Grace", artist=jeff_buckley, release_year=1994)
    
    # Add songs to that album
    dream_brother = Song(title="Dream Brother", position=10, album=grace)
    mojo_pin = Song(title="Mojo Pin", position=1, album=grace)
    lilac_wine = Song(title="Lilac Wine", position=4, album=grace)

def display_info(artist):
    for album in artist.albums:
        message = """
        %s released %s in %d
        It contains the following songs:\n""" % (artist.name,
                                                 album.title,
                                                 album.release_year)
        for song in album.songs:
            message = message + "       %s\n" % (song.title, )
        print message

if __name__ == '__main__':
    create_tables()

    play()
    
    # Retrieve an artist by his name
    buckley = Artist.byName('Jeff Buckley')
    display_info(buckley)

    # Retrieve songs containing the word 'la' from the given artist
    # The AND() function is provided by the SQLObject namespace
    songs = Song.select(AND(Artist.q.name=="Jeff Buckley",
                            Song.q.title.contains("la")))
    for song in songs:
        print "  %s" % (song.title,)

    # Retrieve all songs but only display some of them
    songs = Song.select()
    print "Found %d songs, let's show only a few of them:" % (songs.count(), )
    for song in songs[1:-1]:
        print "  %s" % (song.title,)

    # Retrieve an album by its ID
    album = Album.get(1)
    print album.title

    # Delete the album and all its dependencies
    # since we have specified cascade delete
    album.destroySelf()

    drop_tables()
