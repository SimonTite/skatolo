import dejavu
from dejavu import Unit, UnitProperty

arena = dejavu.Arena()

class Song(Unit):
    title = UnitProperty(unicode)
    position = UnitProperty(int)
    album_id = UnitProperty(int, index=True)

class Album(Unit):
    title = UnitProperty(unicode)
    release_year = UnitProperty(int)
    artist_id = UnitProperty(int, index=True)

    def songs(self):
        return self.Song()
    songs = property(songs)

    def artist(self):
        return self.Artist()
    artist = property(artist)

    def on_forget(self):
        for song in self.Song():
            song.forget()

class Artist(Unit):
    name = UnitProperty(unicode)

    def albums(self):
        return self.Album()
    albums = property(albums)

    def on_forget(self):
        for album in self.Album():
            album.forget()

Album.one_to_many('ID', Song, 'album_id')
Artist.one_to_many('ID', Album, 'artist_id')

def init():
    # Create the global arena object
    arena.logflags = dejavu.logflags.SQL + dejavu.logflags.IO

    # Add a storage to the main arena object
    # dejavu does not support the 'in memory' feature of SQLlite 
    # so we provide the name of a physical database on the filesystem
    conf = {'Connect': "host=localhost dbname=cdtek user=test password=test"}
    arena.add_store("main", "postgres", conf)

    # Register units the arena will be allowed to handle
    # This call must happen after the declaration of the units
    # and those must be part of the current namespace
    arena.register_all(globals())

def create_tables():
    arena.create_storage(Song)
    arena.create_storage(Album)
    arena.create_storage(Artist)

def drop_tables():
    arena.drop_storage(Song)
    arena.drop_storage(Album)
    arena.drop_storage(Artist)

def play():
    sandbox = arena.new_sandbox()

    # Create an artist unit 
    jeff_buckley = Artist(name="Jeff Buckley")
    sandbox.memorize(jeff_buckley)

    grace = Album(title="Grace", release_year=1994)
    sandbox.memorize(grace)

    # Add the album unit to the artist unit
    jeff_buckley.add(grace)

    dream_brother = Song(title="Dream Brother", position=10)
    sandbox.memorize(dream_brother)

    mojo_pin = Song(title="Mojo Pin", position=1)
    sandbox.memorize(mojo_pin)

    lilac_wine = Song(title="Lilac Wine", position=4)
    sandbox.memorize(lilac_wine)

    # Add each song unit to the album unit
    grace.add(dream_brother)
    grace.add(mojo_pin)
    grace.add(lilac_wine)

    sandbox.flush_all()

def display_info(artist):
    for album in artist.albums:
        message = """
        %s released %s in %d
        It contains the following songs:\n""" % (artist.name,
                                                 album.title,
                                                 album.release_year)
        for song in album.songs:
            message = message + "       %s\n" % (song.title, )
        print message

if __name__ == '__main__':
    init()
    create_tables()

    play()
    
    sandbox = arena.new_sandbox()

    # Retrieve an artist by his name
    buckley = sandbox.Artist(name="Jeff Buckley")
    display_info(buckley)

    # Retrieve songs containing the word 'la' from the given artist
    # We will explain in more details the concepts of Expressions
    f = lambda ar, al, s: ar.name == "Jeff Buckley" and "la" in s.title
    #e = logic.Expression(f)
    # Note how we express the composition between the units
    results = sandbox.recall(Artist & Album & Song, f)
    for artist, album, song in results:
        print "  %s" % (song.title,)

    # Retrieve all songs but only display some of them
    songs = sandbox.recall(Song)
    print "Found %d songs, let's show only a few of them:" % (len(songs), )
    for song in songs[1:-1]:
        print "  %s" % (song.title,)

    # Retrieve an album by its ID
    album = sandbox.Album(ID=1)
    print album.title

    drop_tables()
