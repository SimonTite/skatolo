# -*- coding: utf-8 -*-

from funkload.FunkLoadTestCase import FunkLoadTestCase

class LoadHomePage(FunkLoadTestCase):
    def test_homepage(self):
        server_url = self.conf_get('main', 'url')
        nb_time = self.conf_getInt('test_homepage', 'nb_time')

        home_page = "%s/" % server_url
        for i in range(nb_time):
            self.logd('Try %i' % i)
            self.get(home_page, description='Get gome page')

if __name__ in ('main', '__main__'):
    import unittest
    unittest.main()
