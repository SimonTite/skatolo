# -*- coding: utf-8 -*-

from funkload.FunkLoadTestCase import FunkLoadTestCase

class CreateAlbum(FunkLoadTestCase):
    def test_create_album(self):
        server_url = self.conf_get('main', 'url')
        params = {'title': 'Test2', 
                  'author': 'Test demo', 'description': 'blah blah',
                  'content': 'more blah blah bluh', 'blog_id': '1'}

        #self.setHeader('Content-Type', 'multipart/form-data')
        self.addHeader('Accept', 'application/json')
        self.setBasicAuth('test', 'test')
        response = self.post(server_url, params=params, description="Create a new album",
                             ok_codes=[201])
        self.clearBasicAuth()

if __name__ in ('main', '__main__'):
    import unittest
    suite = unittest.TestSuite((CreateAlbum, ))
    unittest.main(testRunner=unittest.TextTestRunner(descriptions=2, verbosity=2))
