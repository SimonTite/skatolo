# -*- coding: utf-8 -*-

import unittest
import dejavu

from lib import storage
from models import Photoblog, Album, Film, Photo

from blogtest import PhotoblogTest, blog_name

_dummy_blog_name = u"dummy"

class TestModels(PhotoblogTest):
    def test_00_Photoblog_unit(self):
        self.assertEqual(Photoblog.Album.__class__, dejavu.ToMany)
        self.assertEqual(Photoblog.Album.nearClass, Photoblog)
        self.assertEqual(Photoblog.Album.nearKey, 'ID')
        self.assertEqual(Photoblog.Album.farClass, Album)
        self.assertEqual(Photoblog.Album.farKey, 'blog_id')
        
        self.assertEqual(Album.Photoblog.__class__, dejavu.ToOne)
        self.assertEqual(Album.Photoblog.nearClass, Album)
        self.assertEqual(Album.Photoblog.nearKey, 'blog_id')
        self.assertEqual(Album.Photoblog.farClass, Photoblog)
        self.assertEqual(Album.Photoblog.farKey, 'ID')

    def test_01_Photoblog_create(self):
        blog = Photoblog()
        blog.create(blog_name, u"Demo Photoblog")
        self.assertEqual(blog.name, u"photoblog")
        self.assertEqual(blog.title, u"Demo Photoblog")
        
        blog = Photoblog()
        dummy = blog.create(_dummy_blog_name, u"A dummy Photoblog")
        
    def test_02_Photoblog_retrieve_by_name(self):
        blog = Photoblog.find_by_name(_dummy_blog_name)

        self.assertEqual(blog.name, _dummy_blog_name)

    def test_03_Photoblog_retrieve_by_unknown_name(self):
        blog = Photoblog.find_by_name(u"meh")
        if blog:
            self.fail("Should not have retrieved photoblog with name 'meh'")

    def test_04_Photoblog_retrieve_by_unsupported_id_type(self):
        # test that the fetch method only accepts integers
        self.failUnlessRaises(ValueError, Photoblog.fetch, "")
        for a_type in [None, {}, [], ()]:
            self.failUnlessRaises(TypeError, Photoblog.fetch, a_type)

    def test_05_Photoblog_update(self):
        blog = Photoblog.find_by_name(_dummy_blog_name)
        blog.update(u'A new title')

        blog1 = Photoblog.find_by_name(_dummy_blog_name)

        self.assertEqual(blog.name, blog1.name)
        self.assertEqual(blog.title, blog1.title)

    def test_06_Photoblog_populate(self):
        blog = Photoblog.find_by_name(_dummy_blog_name)
        self.assertEqual(len(blog.albums), 0)
        album = Album()
        album.create(blog, "Test album", "Test", "blah blah", "more blah blah")
        albums = blog.albums
        self.assertEqual(len(albums), 1)
        album1 = albums[0]
        
        self.assertEqual(album.title, album1.title)
        self.assertEqual(album.author, album1.author)
        self.assertEqual(album.description, album1.description)
        self.assertEqual(album.content, album1.content)
        
    def test_99_Photoblog_delete(self):
        blog = Photoblog.find_by_name(_dummy_blog_name)
        album = blog.albums[0]

        blog.delete()
        blog = Photoblog.find_by_name(_dummy_blog_name)
        if blog:
            self.fail("Failed to delete blog '%s'" % _dummy_blog_name)

        album = Album.fetch(album.ID)

        if album:
            self.fail("The album attached to the blog has not been deleted")
            
    def test_10_Album_unit(self):
        self.assertEqual(Album.Film.__class__, dejavu.ToMany)
        self.assertEqual(Album.Film.nearClass, Album)
        self.assertEqual(Album.Film.nearKey, 'ID')
        self.assertEqual(Album.Film.farClass, Film)
        self.assertEqual(Album.Film.farKey, 'album_id')
        
        self.assertEqual(Film.Album.__class__, dejavu.ToOne)
        self.assertEqual(Film.Album.nearClass, Film)
        self.assertEqual(Film.Album.nearKey, 'album_id')
        self.assertEqual(Film.Album.farClass, Album)
        self.assertEqual(Film.Album.farKey, 'ID')

        

if __name__ == '__main__':
    suite = unittest.TestSuite((TestModelPhotoblog, TestModelAlbum))
    unittest.main(testRunner=unittest.TextTestRunner(descriptions=2, verbosity=2))
