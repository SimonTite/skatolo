# -*- coding: utf-8 -*-

import os.path
import cherrypy
from cherrypy.test import helper

from lib import storage
import controllers
import services
from models import Photoblog, Album, Film, Photo

# dejavu main arena object
arena = storage.arena
blog_name = u"photoblog"

class PhotoblogTest(helper.CPWebCase):
    def photoblog(self):
        blog = Photoblog.find_by_name(blog_name)
        if not blog:
            self.fail("Could not find blog '%s'" % blog_name)

        return blog
    photoblog = property(photoblog, doc="Returns a blog object to work against")
 
current_dir = os.path.abspath(os.path.dirname(__file__))

def populate_storage():
    for cls in (Photoblog, Album, Film, Photo):
        arena.create_storage(cls)
    photoblog = Photoblog()
    photoblog.create(blog_name, u'Yeah')
    a1 = Album()
    a1.create(photoblog, "Test album", "Test", "blah blah", "more blah blah")

def reset_storage():
    photoblog = Photoblog.find_by_name(blog_name)
    photoblog.delete()
    for cls in (Photoblog, Album, Film, Photo):
        if arena.has_storage(cls):
            arena.drop_storage(cls)

def setup_photoblog_server():
    # Update the CherryPy global configuration
    cherrypy.config.update(os.path.join(current_dir, 'etc', 'http.conf'))

    populate_storage()

    # Construct the published trees
    #blog_app = controllers.construct_app()
    services_app = services.construct_app()

    # Mount the applications on the '/' prefix
    engine_conf_path = os.path.join(current_dir, 'etc', 'engine.conf')
    #photoblog_app = cherrypy.tree.mount(blog_app, '/', config=engine_conf_path)
    service_app = cherrypy.tree.mount(services_app, '/services', config=engine_conf_path)
    service_app.merge(services.services_conf)

def teardown_photoblog_server():
    reset_storage()
    
