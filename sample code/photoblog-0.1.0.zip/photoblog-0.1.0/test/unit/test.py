# -*- coding: utf-8 -*-

import os.path
import sys
sys.path.append(os.path.abspath(os.path.join('..', '..')))

# CherryPy main test module
from cherrypy.test import test as cptest

from lib import conf, taskhandler
from lib import storage, design
from models import Photoblog, Album, Film, Photo

# load the global application settings
current_dir = os.path.abspath(os.path.dirname(__file__))
task_handler = taskhandler.TaskHandler()

# dejavu main arena object
arena = storage.arena

def initialize():
    """initialize the storage""" 
    conf.from_ini(os.path.join(current_dir, 'etc', 'application.conf'))
    # register our models with dejavu
    storage.setup()
    design.setup()
    for cls in (Photoblog, Album, Film, Photo):
        arena.create_storage(cls)
    taskhandler.start(task_handler)

def shutdown():
    """delete any table created by the storage so that we
    can replay the test"""
    taskhandler.stop(task_handler)
    for cls in (Photoblog, Album, Film, Photo):
        try:
            arena.drop_storage(cls)
        except KeyError:
            pass

def run():
    """
    entry point to the test suite
    """
    try:
        initialize()
        # modules name without the trailing .py
        # that this test will run. They must belong
        # to the same directory as test.py
        test_list = ['test_models', 'test_services']
        cptest.CommandLineParser(test_list).run()
    finally:
        shutdown()
    print
    raw_input('hit enter to terminate the test')

if __name__ == '__main__':
    run()
