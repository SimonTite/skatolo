# -*- coding: utf-8 -*-

import httplib
import os.path
import urllib

import cherrypy
import simplejson
from bridge import Element as E
from bridge.common import THR_NS, THR_PREFIX
from amplee.utils import extract_uuid_from_urn

from models import Photoblog, Album, Film, Photo

from blogtest import PhotoblogTest, blog_name, \
     setup_photoblog_server, teardown_photoblog_server

current_dir = os.path.abspath(os.path.dirname(__file__))

def setup_server():
    setup_photoblog_server()

def teardown_server():
    teardown_photoblog_server()
    
class TestServicesREST(PhotoblogTest):
    def test_00_REST(self):
        self.getPage("/services/rest", [('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(404)
        
        self.getPage("/services/rest/", [('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(404)
        
        self.getPage("/services/rest/album/", method="XYU",
                     headers=[('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(405)
        
    def test_02_REST_HEAD(self):
        self.getPage("/services/rest/album/1", method="HEAD",
                     headers=[("Accept", "application/json"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        self.assertHeader('Content-Type', 'application/json')
        self.assertHeader('Allow', 'DELETE, GET, HEAD, POST, PUT')
        
        self.getPage("/services/rest/album/1", method="HEAD",
                     headers=[("Accept", "application/atom+xml"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        self.assertHeader('Content-Type', 'application/atom+xml;type=entry')
        self.assertHeader('Allow', 'DELETE, GET, HEAD, POST, PUT')
        
        self.getPage("/services/rest/album/1", method="HEAD",
                     headers=[("Accept", "application/xml"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        self.assertHeader('Content-Type', 'application/atom+xml;type=entry')
        self.assertHeader('Allow', 'DELETE, GET, HEAD, POST, PUT')
        
    def test_03_REST_GET(self):
        self.getPage("/services/rest/album/", [('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(400)
        
        self.getPage("/services/rest/album/2", [('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(406)

        self.getPage("/services/rest/album/st",
                     headers=[("Accept", "application/json"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(404)
        
        self.getPage("/services/rest/album/1",
                     headers=[("Accept", "application/json"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        self.assertHeader('Content-Type', 'application/json')
        self.assertHeader('Allow', 'DELETE, GET, HEAD, POST, PUT')
        
        self.getPage("/services/rest/album?album_id=1",
                     headers=[("Accept", "application/json"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        self.assertHeader('Content-Type', 'application/json')
        self.assertHeader('Allow', 'DELETE, GET, HEAD, POST, PUT')

    def test_01_REST_POST(self):
        params = {'title': 'Test2', 'author': 'Test demo', 'description': 'blah blah',
                  'content': 'more blah blah bluh', 'blog_id': '2'}
        query_string = urllib.urlencode(params)
        self.getPage("/services/rest/album/", method="POST",
                     body=query_string,
                     headers=[("Content-Type", "application/x-www-form-urlencoded"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0'),
                              ("Accept", "application/json"),
                              ("Content-Length", str(len(query_string)))])
        self.assertStatus(400)

        blog = self.photoblog
        params['blog_id'] = str(blog.ID)
        query_string = urllib.urlencode(params)

        self.getPage("/services/rest/album/", method="POST",
                     body=query_string,
                     headers=[("Content-Type", "application/x-www-form-urlencoded"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0'),
                              ("Accept", "application/json"),
                              ("Content-Length", str(len(query_string)))])
        self.assertStatus(201)
        self.assertHeader('Content-Type', 'application/json')

        self.getPage("/services/rest/album/", method="POST",
                     body=query_string, headers=[('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(201)
        self.assertHeader('Content-Type', 'application/atom+xml;type=entry')

        params = {'title': 'A film of this afternoon', 'description': 'This afternoon I went...', 'album_id': '1'}
        query_string = urllib.urlencode(params)
        self.getPage("/services/rest/film/", method="POST",
                     body=query_string,
                     headers=[("Content-Type", "application/x-www-form-urlencoded"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0'),
                              ("Accept", "application/json"),
                              ("Content-Length", str(len(query_string)))])
        self.assertStatus(201)
        self.assertHeader('Content-Type', 'application/json')

        params = {'name': 'A bench', 'legend': 'old bench', 'film_id': '2'}
        query_string = urllib.urlencode(params)
        self.getPage("/services/rest/photograph/", method="POST",
                     body=query_string,
                     headers=[("Content-Type", "application/x-www-form-urlencoded"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0'),
                              ("Accept", "application/json"),
                              ("Content-Length", str(len(query_string)))])
        self.assertStatus(201)
        self.assertHeader('Content-Type', 'application/json')

    def test_04_REST_PUT(self):
        params = {'title': 'Test2', 'author': 'Test demo', 'description': 'blah blah',
                  'content': 'meh ehe eh', 'blog_id': '1'}
        query_string = urllib.urlencode(params)
        
        self.getPage("/services/rest/album/23", method="PUT",
                     body=query_string,
                     headers=[("Content-Type", "application/x-www-form-urlencoded"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0'),
                              ("Accept", "application/json"),
                              ("Content-Length", str(len(query_string)))])
        self.assertStatus(404)
        
        self.getPage("/services/rest/album/1", method="PUT",
                     body=query_string,
                     headers=[("Accept", "application/json"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        self.assertHeader('Content-Type', 'application/json')

        def encode_multipart_formdata(path):
            filename = os.path.basename(path)
            BOUNDARY = 'T65boundary'
            body = []
            body.append('')
            body.append('--' + BOUNDARY)
            body.append('Content-Disposition: form-data; name="photography"; filename="%s"' % filename)
            body.append('Content-Type: image/png')
            body.append('Content-Transfer-Encoding: binary')
            body.append('')
            body.append(file(path, 'rb').read())
            body.append('--' + BOUNDARY + '--')
            body.append('')
            return 'multipart/form-data; boundary=%s' % BOUNDARY, '\r\n'.join(body)

        content_type, body = encode_multipart_formdata(os.path.join(current_dir, 'data', 'hello.png'))
        self.getPage("/services/rest/photograph/upload/2", method="PUT",
                     body=body,
                     headers=[("Content-Type", content_type),
                              ('Authorization', 'Basic dGVzdDp0ZXN0'),
                              ("Content-Length", str(len(body)))])
        self.assertStatus(200)
        
    def test_06_REST_DELETE(self):
        self.getPage("/services/rest/photograph/2", method="DELETE",
                     headers=[('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        
        self.getPage("/services/rest/album/4", method="DELETE",
                     headers=[('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        
        self.getPage("/services/rest/album/4", method="DELETE",
                     headers=[('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        
    def test_05_REST_Collection_GET(self):
        self.getPage("/services/rest/albums/3",
                     [('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(400, 'Invalid range')
        
        self.getPage("/services/rest/albums/a",
                     [('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(400, 'Invalid range')
        
        self.getPage("/services/rest/albums/0-",
                     [('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(400, 'Invalid range')
        
        self.getPage("/services/rest/albums/a+3",
                     [('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(400, 'Invalid range')
        
        self.getPage("/services/rest/albums/3-a",
                     [('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(400, 'Invalid range')
        
        self.getPage("/services/rest/albums/0+3",
                     [('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(400, 'Invalid range')
        
        self.getPage("/services/rest/albums/0-3",
                     [('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(406)
        
        self.getPage("/services/rest/albums/0-3",
                     headers=[("Accept", "application/json"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        self.assertHeader('Content-Type', 'application/json')
        json = simplejson.loads(self.body)
        self.failUnless(isinstance(json, list))
        self.failUnlessEqual(len(json), 3)
        
        self.getPage("/services/rest/albums/0-2",
                     headers=[("Accept", "application/json"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        self.assertHeader('Content-Type', 'application/json')
        json = simplejson.loads(self.body)
        self.failUnless(isinstance(json, list))
        self.failUnlessEqual(len(json), 2)
        
        self.getPage("/services/rest/albums?range=0-3",
                     headers=[("Accept", "application/json"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        self.assertHeader('Content-Type', 'application/json')
        json = simplejson.loads(self.body)
        self.failUnless(isinstance(json, list))
        self.failUnlessEqual(len(json), 3)
        
        self.getPage("/services/rest/albums/0-300",
                     headers=[("Accept", "application/json"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        self.assertHeader('Content-Type', 'application/json')
        json = simplejson.loads(self.body)
        self.failUnless(isinstance(json, list))
        self.failUnlessEqual(len(json), 3)
        
        self.getPage("/services/rest/albums/30-300",
                     headers=[("Accept", "application/json"),
                              ('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        self.assertHeader('Content-Type', 'application/json')
        json = simplejson.loads(self.body)
        self.failUnless(isinstance(json, list))
        self.failUnlessEqual(len(json), 0)

    def test_07_REST_Pipelined(self):
        # force 1.1 protocol for pipelining
        self.PROTOCOL = "HTTP/1.1"

        conn = httplib.HTTPConnection(self.HOST, self.PORT)
        conn.auto_open = False
        conn.connect()

        conn.putrequest("GET", "/services/rest/albums/0-2", skip_host=True)
        conn.putheader('Accept', 'application/json')
        conn.putheader('Authorization', 'Basic dGVzdDp0ZXN0')
        conn.putheader("Host", self.HOST)
        conn.endheaders()

        conn._output('GET /services/rest/albums/2-3 HTTP/1.1')
        conn._output("Host: %s" % self.HOST)
        conn._output('Authorization: Basic dGVzdDp0ZXN0')
        conn._output('Accept: application/json')
        conn._send_output()

        conn._output('GET /services/rest/albums/0-3 HTTP/1.1')
        conn._output("Host: %s" % self.HOST)
        conn._output('Authorization: Basic dGVzdDp0ZXN0')
        conn._send_output()

        # Retrieve response from first request
        response = conn.response_class(conn.sock, method="GET")
        response.begin()
        body = response.read()
        self.assertEqual(response.status, 200)
        json = simplejson.loads(body)
        self.failUnless(isinstance(json, list))
        self.failUnlessEqual(len(json), 2)

        # Retrieve response from second request
        response = conn.response_class(conn.sock, method="GET")
        response.begin()
        body = response.read()
        self.assertEqual(response.status, 200)
        json = simplejson.loads(body)
        self.failUnless(isinstance(json, list))
        self.failUnlessEqual(len(json), 0)

        # Retrieve response from last request
        response = conn.response_class(conn.sock, method="GET")
        response.begin()
        body = response.read()
        self.assertEqual(response.status, 406)

        conn.close()

        
class TestServicesAtomPub(PhotoblogTest):
    def test_00_AtomPub_GET(self):
        self.getPage("/services/atompub",
                     [('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        self.assertHeader('Content-Type', 'application/atomsvc+xml')
        self.assertHeader('Allow', 'GET, HEAD')
        
        self.getPage("/services/atompub/",
                     [('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        self.assertHeader('Content-Type', 'application/atomsvc+xml')
        self.assertHeader('Allow', 'GET, HEAD')
        
        self.getPage("/services/atompub/albums/", method="XYU",
                     headers=[('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(405)
        
    def test_01_AtomPub_POST(self):
        content = file(os.path.join(current_dir, 'data', 'entry.atom'), 'rb').read()
        self.getPage("/services/atompub/albums/", method="POST",
                     headers= [('Content-Type', 'application/atom+xml'),
                               ('Authorization', 'Basic dGVzdDp0ZXN0'),
                               ('Content-Length', len(content))],
                     body=content)
        self.assertStatus(201)
        self.assertHeader('Allow', 'DELETE, GET, HEAD, POST, PUT')
        self.assertHeader('Content-Type', 'application/atom+xml')
        member = E.load(self.body).xml_root
        member_id = member.get_child('id', member.xml_ns)
        
        content = file(os.path.join(current_dir, 'data', 'entry.atom'), 'rb').read()
        e = E.load(content).xml_root
        E(u'in-reply-to', attributes={u'ref': extract_uuid_from_urn(member_id.xml_text)},
          prefix=THR_PREFIX, namespace=THR_NS, parent=e)
        content = e.xml(indent=False)
        self.getPage("/services/atompub/films/", method="POST",
                     headers= [('Content-Type', 'application/atom+xml'),
                               ('Authorization', 'Basic dGVzdDp0ZXN0'),
                               ('Content-Length', len(content))],
                     body=content)
        self.assertStatus(201)
        self.assertHeader('Allow', 'DELETE, GET, HEAD, POST, PUT')
        self.assertHeader('Content-Type', 'application/atom+xml')
        member = E.load(self.body).xml_root
        member_id = member.get_child('id', member.xml_ns)
        
        content = file(os.path.join(current_dir, 'data', 'entry.atom'), 'rb').read()
        e = E.load(content).xml_root
        E(u'in-reply-to', attributes={u'ref': extract_uuid_from_urn(member_id.xml_text)},
          prefix=THR_PREFIX, namespace=THR_NS, parent=e)
        content = e.xml(indent=False)
        self.getPage("/services/atompub/photographs/", method="POST",
                     headers= [('Content-Type', 'application/atom+xml'),
                               ('Authorization', 'Basic dGVzdDp0ZXN0'),
                               ('Content-Length', len(content))],
                     body=content)
        self.assertStatus(201)
        self.assertHeader('Allow', 'DELETE, GET, HEAD, POST, PUT')
        self.assertHeader('Content-Type', 'application/atom+xml')

    def test_02_AtomPub_GET(self):
        self.getPage("/services/atompub/albums/2",
                     [('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(406)
        
        self.getPage("/services/atompub/albums/2.atom",
                     [('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(406)
        
        self.getPage("/services/atompub/albums/2.atom",
                     headers= [('Accept', 'application/atom+xml'),
                               ('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        
    def test_03_AtomPub_PUT(self):
        content = file(os.path.join(current_dir, 'data', 'entry.atom'), 'rb').read()
        self.getPage("/services/atompub/albums/2", method="PUT",
                     headers= [('Content-Type', 'application/atom+xml'),
                               ('Authorization', 'Basic dGVzdDp0ZXN0'),
                               ('Content-Length', len(content))],
                     body=content)
        self.assertStatus(200)
        self.assertHeader('Allow', 'DELETE, GET, HEAD, POST, PUT')
        self.assertHeader('Content-Type', 'application/atom+xml')
        
        content = file(os.path.join(current_dir, 'data', 'hello.png'), 'rb').read()
        self.getPage("/services/atompub/photographs/1", method="PUT",
                     headers= [('Content-Type', 'image/png'),
                               ('Authorization', 'Basic dGVzdDp0ZXN0'),
                               ('Content-Length', len(content))],
                     body=content)
        self.assertStatus(200)
        self.assertHeader('Allow', 'DELETE, GET, HEAD, POST, PUT')
        self.assertHeader('Content-Type', 'application/atom+xml')

    def test_04_AtomPub_DELETE(self):
        self.getPage("/services/atompub/photographs/1", method="DELETE",
                     headers=[('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        
        self.getPage("/services/atompub/albums/2", method="DELETE",
                     headers=[('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)
        
        self.getPage("/services/atompub/albums/2", method="DELETE",
                     headers=[('Authorization', 'Basic dGVzdDp0ZXN0')])
        self.assertStatus(200)

if __name__ == '__main__':
    import unittest
    suite = unittest.TestSuite((TestModelPhotoblog, TestModelAlbum))
    unittest.main(testRunner=unittest.TextTestRunner(descriptions=2, verbosity=2))
