# -*- coding: utf-8 -*-

from optparse import OptionParser
import httplib2

def create_resource(target, path, accept_media_type):
    h = httplib2.Http()
    body = file(path, 'rb').read()
    h.add_credentials('test', 'test')
    r, c = h.request('http://localhost:8080/services/rest/%s/' % target,
                     method='POST', body=body,
                     headers={'content-type': 'application/x-www-form-urlencoded',
                              'accept': accept_media_type})
    print r
    print c
    
def parse_command_line():
    parser = OptionParser()
    parser.add_option("-t", "--target", dest="target",
                      help="name of the target ('album', 'film', 'photograph')")
    parser.add_option("-f", "--filepath", dest="filepath",
                      help="path to the file containing an URL encoded content respecting the interface of the service handling target")
    parser.add_option("-a", "--accept-media-type", dest="accept_media_type",
                      help="media-type expected in the response")

    (options, args) = parser.parse_args()
    return options.target, options.filepath, options.accept_media_type

if __name__ == '__main__':
    target, path, media_type = parse_command_line()
    create_resource(target, path, media_type)
