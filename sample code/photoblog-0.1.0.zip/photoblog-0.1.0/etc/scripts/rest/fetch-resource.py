# -*- coding: utf-8 -*-

from optparse import OptionParser
import httplib2

def fetch_resource(uri, media_type, use_head):
    h = httplib2.Http()
    method = 'GET'
    if use_head:
        method = 'HEAD'
    h.add_credentials('test', 'test')
    r, c = h.request(uri, method=method, headers={'accept': media_type})
    print r
    print c
    
def parse_command_line():
    parser = OptionParser()
    parser.add_option("-u", "--uri", dest="uri", help="resource URI")
    parser.add_option("-m", "--media-type", dest="media_type",
                      help="media-type of the requested resource")
    parser.add_option("-b", "--use-HEAD-only", dest="use_head", action="store_true",
                      help="use a HEAD request only", default=False)
    (options, args) = parser.parse_args()
    return options.uri, options.media_type, options.use_head

if __name__ == '__main__':
    uri, media_type, use_head = parse_command_line()
    fetch_resource(uri, media_type, use_head)
