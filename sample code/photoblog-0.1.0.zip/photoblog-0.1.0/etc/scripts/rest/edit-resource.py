# -*- coding: utf-8 -*-

from optparse import OptionParser
import httplib2

def edit_resource(uri, path):
    h = httplib2.Http()
    body = file(path, 'rb').read()
    h.add_credentials('test', 'test')
    r, c = h.request(uri, method='PUT', body=body,
                     headers={'content-type': 'application/x-www-form-urlencoded'})
    print r
    
def parse_command_line():
    parser = OptionParser()
    parser.add_option("-u", "--uri", dest="uri", help="resource URI")
    parser.add_option("-f", "--filepath", dest="filepath",
                      help="path to the file containing the edited content")

    (options, args) = parser.parse_args()
    return options.uri, options.filepath

if __name__ == '__main__':
    uri, path = parse_command_line()
    edit_resource(uri, path)
