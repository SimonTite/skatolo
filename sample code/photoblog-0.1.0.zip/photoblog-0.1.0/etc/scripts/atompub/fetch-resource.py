# -*- coding: utf-8 -*-

from optparse import OptionParser
import httplib2

def fetch_resource(uri):
    h = httplib2.Http()
    h.add_credentials('test', 'test')
    r, c = h.request(uri, headers={'accept': 'application/atom+xml'})
    print c
    
def parse_command_line():
    parser = OptionParser()
    parser.add_option("-u", "--uri", dest="uri", help="resource URI")
    (options, args) = parser.parse_args()
    return options.uri

if __name__ == '__main__':
    uri = parse_command_line()
    fetch_resource(uri)
