# -*- coding: utf-8 -*-

from optparse import OptionParser
import httplib2

def create_resource(collection, path):
    h = httplib2.Http()
    body = file(path, 'rb').read()
    h.add_credentials('test', 'test')
    r, c = h.request('http://localhost:8080/services/atompub/%s/' % collection,
                     method='POST', body=body,
                     headers={'content-type': 'application/atom+xml'})
    print r
    print c
    
def parse_command_line():
    parser = OptionParser()
    parser.add_option("-c", "--collection", dest="collection",
                      help="name of the collection ('albums', 'films', 'photographs')")
    parser.add_option("-f", "--filepath", dest="filepath",
                      help="path to the file containing an atom entry")

    (options, args) = parser.parse_args()
    return options.collection, options.filepath

if __name__ == '__main__':
    collection, path = parse_command_line()
    create_resource(collection, path)
