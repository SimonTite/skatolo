# -*- coding: utf-8 -*-

from optparse import OptionParser
import httplib2

def fetch_collection(collection):
    h = httplib2.Http()
    h.add_credentials('test', 'test')
    r, c = h.request('http://localhost:8080/services/atompub/%s' % collection)
    print c
    
def parse_command_line():
    parser = OptionParser()
    parser.add_option("-c", "--collection", dest="collection",
                      help="name of the collection ('albums', 'films', 'photographs')")
    (options, args) = parser.parse_args()
    return options.collection

if __name__ == '__main__':
    collection = parse_command_line()
    fetch_collection(collection)
