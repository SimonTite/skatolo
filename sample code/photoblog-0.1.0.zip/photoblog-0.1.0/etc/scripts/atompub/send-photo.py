# -*- coding: utf-8 -*-

import mimetypes
mimetypes.init()

from optparse import OptionParser
import httplib2

def edit_resource(uri, path, media_type=None):
    h = httplib2.Http()
    if not media_type:
        media_type = mimetypes.guess_type(path)[0]
    body = file(path, 'rb').read()
    h.add_credentials('test', 'test')
    r, c = h.request(uri, method='PUT', body=body,
                     headers={'content-type': media_type})
    print r
    
def parse_command_line():
    parser = OptionParser()
    parser.add_option("-u", "--uri", dest="uri", help="resource URI")
    parser.add_option("-m", "--media-type", dest="media_type", help="photograph media-type")
    parser.add_option("-f", "--filepath", dest="filepath",
                      help="path to the photograph to send")

    (options, args) = parser.parse_args()
    return options.uri, options.filepath, options.media_type

if __name__ == '__main__':
    uri, path, media_type = parse_command_line()
    edit_resource(uri, path, media_type)
