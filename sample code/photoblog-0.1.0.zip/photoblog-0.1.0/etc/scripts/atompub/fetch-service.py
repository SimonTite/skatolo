# -*- coding: utf-8 -*-

import httplib2

def fetch_service():
    h = httplib2.Http()
    h.add_credentials('test', 'test')
    r, c = h.request('http://localhost:8080/services/atompub/')
    print c
    
if __name__ == '__main__':
    fetch_service()
