# -*- coding: utf-8 -*-

import cherrypy

from lib import conf
from rest import setup_rest
from atompub import setup_store

class Service(object):
    @cherrypy.expose
    def default(self, *args, **kwargs):
        return 
    
def construct_app():
    services = Service()
    services.rest = setup_rest()
    services.atompub = setup_store()

    return services

def get_user():
    return {conf.app.username: conf.app.hashed_password}

_http_method_dispatcher = cherrypy.dispatch.MethodDispatcher()
services_conf = {'/rest': {'request.dispatch': _http_method_dispatcher,
                           'tools.etags.on': False,},
                 '/atompub': {'request.dispatch': _http_method_dispatcher,
                              'tools.etags.on': False,},
                 '/': {'tools.basic_auth.on': True,
                       'tools.basic_auth.realm': 'localhost',
                       'tools.basic_auth.users': get_user}}
                 
