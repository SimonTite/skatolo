# -*- coding: utf-8 -*-

import cherrypy
import mimetypes
mimetypes.init()
from models import Film, Photo
from _resource import Resource
from lib import conf
from lib.design import generate
from lib.cachetools import generate_photo_view, delete_photo_view
from lib.taskhandler import tasks, UpdateFileTask, DeleteFileTask
import simplejson

__all__ = ['PhotoRESTService', 'PhotoUploadRESTService', 'PhotoCollectionRESTService']

class PhotoRESTService(Resource):
    exposed = True
    # The entity class that will be used by the Resource class
    _source_class = Photo
    
    def __init__(self):
        Resource.__init__(self, conf.photograph)

    def GET(self, photo_id):
        return self.handle_GET(photo_id)
        
    def POST(self, name, legend, film_id):
        return self.handle_POST(Film, film_id, location_scheme='%s' + conf.photograph.base_uri + '%d',
                                name=name, legend=legend)
        
    def PUT(self, photo_id, name, legend):
        photo = Photo.fetch(photo_id)
        filename = photo.filename
        mediatype = photo.mediatype
        width = photo.width
        height = photo.height
        filesize = photo.filesize
        return self.handle_PUT(photo_id, name=name, legend=legend, filename=filename,
                               mediatype=mediatype, width=width, height=height, filesize=filesize)
        
    def DELETE(self, photo_id):
        photo = Photo.fetch(photo_id)
        previous, next = photo.film.previous_and_next(photo)
        if photo and photo.filename:
            tasks.put(DeleteFileTask(conf.photograph.photographs_directory, photo.filename))
        response = self.handle_DELETE(photo_id, cache_handler=delete_photo_view)
        if previous:
            generate_photo_view(previous)
        if next:
            generate_photo_view(next)

        return response

class PhotoUploadRESTService(object):
    """ This REST web service handles the uploading
    of photograph data.

    When a GET request is made to
    the web service the upload template is generated
    and returned. This template is an HTML page with
    one single form element allowing for the actual
    upload to take place.

    The POST request is actual there to support the
    fact that HTML form only accepts GET and POST
    methods. But ideally a PUT request should be made
    instead since the operation is rather a replacement
    of the current resource at the given URI than
    a processing of data posted.
    
    """

    exposed = True

    def GET(self, photo_id):
        path = conf.app.design_base_path
        template = conf.photograph.upload_template
        return generate(path=path, template=template,
                        params={'photo_id': photo_id})

    def POST(self, photo_id, photography):
        return self.PUT(photo_id, photography)

    def PUT(self, photo_id, photography):
        photo = Photo.fetch(photo_id)
        if not photo:
            raise cherrypy.NotFound()

        # Since the request body is sent as a multipart/form-data, the body itself
        # is fragmented into inner bodies.
        # To access the actual content-type value of the photo sent we must
        # inspect the body itself.
        extension = mimetypes.guess_extension(photography.headers['content-type'])

        # We then use the previous call to set up the correct extension for
        # this kind of media-type
        if extension: filename = "%d%s" % (photo.ID, extension)
        else: filename = "%d" % photo.ID

        # We can now read the data itself
        content = photography.file.read()

        # We put a task that will copy the content onto our filesystem
        tasks.put(UpdateFileTask(conf.photograph.photographs_directory, filename, content))

        # We now update the photograph details
        photo.update(photo.name, photo.legend, filename=filename,
                     mediatype=photography.headers['content-type'], filesize=len(content))
        
        # We can now update the cache for this photograph
        generate_photo_view(photo, update_previous=True, update_next=True)

        return "Uploaded"

class PhotoCollectionRESTService(object):
    exposed = True

    def GET(self, film_id):
        film = Film.fetch(film_id)
        if not film:
            raise cherrypy.NotFound()
        
        photos = film.photos
        cherrypy.response.headers['Content-Type'] = 'application/json'
        result = []
        for photo in photos:
            result.append(photo.to_dict())
        return simplejson.dumps(result)
