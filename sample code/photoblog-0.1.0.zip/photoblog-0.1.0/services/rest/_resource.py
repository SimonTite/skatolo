# -*- coding: utf-8 -*-

# Since the entities manipulated by the photoblog
# all share more or less the same interface
# We can avoid most duplicated code by using
# the following classes that act as a proxy for
# the REST services of each entity.

import cherrypy
from cherrypy.lib.cptools import accept
import simplejson

from models import Photoblog, Album
from lib import conf
from lib.taskhandler import tasks, UpdateFeedTask, \
     DeleteFeedTask

__all__ = ['Resource', 'ResourceCollection']

class Resource(object):
    def __init__(self, conf):
        # The conf section for each entity
        self.conf = conf
        
    def handle_HEAD(self, obj_id):
        # We first check if there was an Accept header matching
        # any of the following media-types.
        best = accept(['application/xml', 'application/atom+xml',
                       'text/json', 'text/x-json', 'application/json'])

        # We lookup for an object with ID equal to obj_id
        obj = self._source_class.fetch(obj_id)
        if not obj:
           raise cherrypy.NotFound()

        # Then we respond with the best matching media-type
        if best in ['application/xml', 'application/atom+xml']:
           cherrypy.response.headers['Content-Type'] = 'application/atom+xml;type=entry'
           entry = obj.to_atom_entry()
           body = entry.xml()
           cherrypy.response.headers['Content-Length'] = len(body)
           # A HEAD request expects the response headers but not
           # the content itself.
           return 
           
        if best in ['text/json', 'text/x-json', 'application/json']:
           cherrypy.response.headers['Content-Type'] = best
           body = obj.to_json()
           cherrypy.response.headers['Content-Length'] = len(body)
           return 
        
        raise cherrypy.HTTPError(400, 'Bad Request')
    
    def handle_GET(self, obj_id):
        if not obj_id:
            raise cherrypy.HTTPError(400, 'Missing identifier')
               
        if not cherrypy.request.headers.elements('Accept'):
            raise cherrypy.HTTPError(406, 'Not Acceptable')
        
        best = accept(['application/xml', 'application/atom+xml',
                       'text/json', 'text/x-json', 'application/json'])

        obj = self._source_class.fetch(obj_id)
        if not obj:
           raise cherrypy.NotFound()
           
        if best in ['application/xml', 'application/atom+xml']:
           cherrypy.response.headers['Content-Type'] = 'application/atom+xml;type=entry'
           entry = obj.to_atom_entry()
           return entry.xml()
           
        if best in ['text/json', 'text/x-json', 'application/json']:
           cherrypy.response.headers['Content-Type'] = best
           return obj.to_json()
        
        raise cherrypy.HTTPError(400, 'Bad Request')

    def handle_POST(self, container_cls, container_id, location_scheme, cache_handler=None, **kwargs):
        # First we search for an instance in the specified container matching the
        # provided container_id
        # For instance when POSTing a film, the container is Album.
        container = container_cls.fetch(container_id)
        if not container:
           raise cherrypy.HTTPError(400, "Could not find the container with %s" % container_id)

        # We create an instance of the source class
        obj = self._source_class()
        # We pass all the parameters provided in the request
        obj.create(container, **kwargs)
        # We has kthe task handler to update the Atom feed of the entity
        tasks.put(UpdateFeedTask(self.conf, obj))
        # If a cache handler is provided we also call it to update the cache
        if cache_handler:
           cache_handler(obj)

        # Now we inspect the Accept header to see which media-type
        # the client is expecting
        best = accept(['application/xml', 'application/atom+xml',
                       'text/json', 'text/x-json', 'application/json'])
        
        cherrypy.response.status = '201 Created'
        # The location scheme is jus ta pattern to create the
        # URL of the Location header appropriatly for the entity
        # For example for a film:
        # location_scheme = '%s/film/%d'
        cherrypy.response.headers['Location'] = location_scheme % (conf.app.base_url, obj.ID)
        
        if best in ['application/xml', 'application/atom+xml']:
           cherrypy.response.headers['Content-Type'] = 'application/atom+xml;type=entry'
           entry = obj.to_atom_entry()
           return entry.xml()
           
        if best in ['text/json', 'text/x-json', 'application/json']:
           cherrypy.response.headers['Content-Type'] = best
           return obj.to_json()

    def handle_PUT(self, obj_id, cache_handler=None, **kwargs):
        obj = self._source_class.fetch(obj_id)
        if not obj:
           raise cherrypy.NotFound()
        
        obj = self._source_class.fetch(obj_id)
        obj.update(**kwargs)
        tasks.put(UpdateFeedTask(self.conf, obj))
        if cache_handler:
            cache_handler(obj)
        
        best = accept(['application/xml', 'application/atom+xml',
                       'text/json', 'text/x-json', 'application/json'])
        
        if best in ['application/xml', 'application/atom+xml']:
           cherrypy.response.headers['Content-Type'] = 'application/atom+xml;type=entry'
           entry = obj.to_atom_entry()
           return entry.xml()
           
        if best in ['text/json', 'text/x-json', 'application/json']:
           cherrypy.response.headers['Content-Type'] = best
           return obj.to_json()

    def handle_DELETE(self, obj_id, cache_handler=None, **kwargs):
        obj = self._source_class.fetch(obj_id)
        if obj:
            tasks.put(DeleteFeedTask(self.conf, obj.ID))
            if cache_handler:
                cache_handler(obj)
            obj.delete()

class ResourceCollection(object):
    def handle_GET(self, start, end):
        # First let's make sure we have an Accept header since we depend on it
        # to return the valid content
        if not cherrypy.request.headers.elements('Accept'):
            raise cherrypy.HTTPError(406, 'Not Acceptable')

        # Currently this method only returns JSON
        best = accept(['text/json', 'text/x-json', 'application/json'])

        # Let's fetch a range of instances for the entity
        # Album.fetch_range(8, 15)
        objs = self._source_class.fetch_range(start, end) or []
        # We return the retrieved range as a list
        # which is serialized into a javascript array.
        if best in ['text/json', 'text/x-json', 'application/json']:
            cherrypy.response.headers['Content-Type'] = best
            result = []
            for obj in objs:
                result.append(obj.to_dict())
            return simplejson.dumps(result)

        raise cherrypy.HTTPError(400, 'Bad Request')
