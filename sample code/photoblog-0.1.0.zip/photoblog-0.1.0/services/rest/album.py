# -*- coding: utf-8 -*-

# REST service for the Album entity

import re
import cherrypy

from models import Photoblog, Album
from lib import conf
from lib.cachetools import generate_page_view, delete_page_view
from _resource import Resource, ResourceCollection

class AlbumRESTService(Resource):
    exposed = True
    # The entity class that will be used by the Resource class
    _source_class = Album
    
    def __init__(self):
        # We keep track of the config section of the album
        Resource.__init__(self, conf.album)

    def HEAD(self, album_id=None):
        if not album_id:
            raise cherrypy.HTTPError(400, "Missing identifier")
        
        return self.handle_HEAD(album_id)

    def GET(self, album_id=None):
        if not album_id:
            raise cherrypy.HTTPError(400, "Missing identifier")
        
        return self.handle_GET(album_id)
        
    def POST(self, title, author, description, content, blog_id):
        return self.handle_POST(Photoblog, blog_id, location_scheme='%s' + conf.album.base_uri + '%d',
                                title=title, author=author, description=description, content=content,
                                cache_handler=generate_page_view)

    def PUT(self, album_id, title, author, description, content, blog_id=None):
        return self.handle_PUT(album_id, title=title, author=author, description=description,
                               content=content, cache_handler=generate_page_view)
        
    def DELETE(self, album_id):
        # Now we can safely remove the atom feed associated with our album
        return self.handle_DELETE(album_id, cache_handler=delete_page_view)

class AlbumCollectionRESTService(ResourceCollection):
    exposed = True
    _range_regex = re.compile('([0-9]+)-([0-9]+)')
    _source_class = Album
    
    def GET(self, range):
        m = self._range_regex.match(range)
        if not m:
            raise cherrypy.HTTPError(400, 'Invalid range')
        start = m.group(1)
        end = m.group(2)
        return self.handle_GET(int(start), int(end))
