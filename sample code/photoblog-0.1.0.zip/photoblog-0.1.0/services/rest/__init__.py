# -*- coding: utf-8 -*-

import cherrypy
from album import AlbumRESTService, AlbumCollectionRESTService
from film import FilmRESTService, FilmCollectionRESTService
from photo import PhotoRESTService, PhotoUploadRESTService, PhotoCollectionRESTService

__all__ = ['setup_rest']

class REST(object):
    exposed = True

    def GET(self):
        cherrypy.response.status = '404 Not Found'
        cherrypy.response.body = 'Not Found'

def setup_rest():
    rest = REST()
    rest.album = AlbumRESTService()
    rest.albums = AlbumCollectionRESTService()
    rest.film = FilmRESTService()
    rest.films = FilmCollectionRESTService()
    rest.photograph = PhotoRESTService()
    rest.photograph.upload = PhotoUploadRESTService()
    rest.photographs = PhotoCollectionRESTService()
    
    return rest
