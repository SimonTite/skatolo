# -*- coding: utf-8 -*-

import cherrypy
from models import Album, Film
from lib import conf
from lib.cachetools import generate_film_view, delete_film_view
from _resource import Resource
import simplejson

__all__ = ['FilmRESTService', 'FilmCollectionRESTService']

class FilmRESTService(Resource):
    exposed = True
    # The entity class that will be used by the Resource class
    _source_class = Film
    
    def __init__(self):
        Resource.__init__(self, conf.film)

    def GET(self, film_id=None):
        return self.handle_GET(film_id)
        
    def POST(self, title, description, album_id):
        return self.handle_POST(Album, album_id, location_scheme='%s' + conf.film.base_uri + '%d',
                                title=title, description=description,
                                cache_handler=generate_film_view)
        
    def PUT(self, film_id, title, description):
        return self.handle_PUT(film_id, title=title, description=description,
                               cache_handler=generate_film_view)
        
    def DELETE(self, film_id):
        return self.handle_DELETE(film_id, cache_handler=delete_film_view)

class FilmCollectionRESTService(object):
    exposed = True

    def GET(self, album_id):
        album = Album.fetch(album_id)
        if not album:
            raise cherrypy.NotFound()
        
        films = album.films
        cherrypy.response.headers['Content-Type'] = 'application/json'
        result = []
        for film in films:
            result.append(film.to_dict())
        return simplejson.dumps(result)
