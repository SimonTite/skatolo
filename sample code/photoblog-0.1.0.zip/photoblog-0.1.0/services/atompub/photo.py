# -*- coding: utf-8 -*-

import os, os.path
import mimetypes
mimetypes.init()
from urlparse import urlparse
from bridge.filter.atom import lookup_links
from bridge import Element as E
from bridge.common import ATOMPUB_NS, THR_NS
from amplee.utils import extract_uuid_from_urn, get_isodate
from amplee.error import ResourceOperationException

from models import Film, Photo
from lib import conf
from lib.cachetools import generate_photo_view, delete_photo_view
from lib.taskhandler import tasks, UpdateFeedTask, DeleteFileTask,\
     UpdateFileTask, UpdateContainerFeedTask

__all__ = ['PhotoAtomHandler', 'PhotoDataHandler']

class PhotoAtomHandler(object):
    def __init__(self, member_type):
        # The media-type that this class will handle
        self.member_type = member_type

    # Called upon creation of a new member
    # It provides the automatically generated member
    # (see amplee.atompub.member.*) and the
    # content sent within the request.
    # This should return the member and the content
    # again but in between you can modify both of
    # them before they get stored in the storage
    def on_create(self, member, content):
        entry = member.atom.xml_root
        # We need to know to which film this photo must be added
        # Because we don't want that value to be passed via the URL
        # we look for a <thr:in-reply-to /> element (RFC 4685) in the Atom entry
        # The element's content is a UUID value identifying
        # the film as its 'ref' attribute.
        # If the element is not present we cannot fulfill the request
        # and therefore abort the request now.
        incoming = E.load(content).xml_root
        in_reply_to = incoming.get_child('in_reply_to', THR_NS)
        if in_reply_to is None:
            # This exception will be interpreted by amplee as an abortion
            raise ResourceOperationException('Missing thr:in-reply-to element (RFC 4685)', 400)

        container = unicode(in_reply_to.get_attribute('ref'))
        
        film_uuid = unicode(container)
        film = Film.fetch_by_uuid(film_uuid)
        
        id = extract_uuid_from_urn(unicode(entry.id))
        title = unicode(entry.get_child('title', entry.xml_ns))
        description = unicode(entry.get_child('summary', entry.xml_ns))

        photo = Photo()
        photo.create(film, title, description, uuid=id)
        tasks.put(UpdateContainerFeedTask(conf.film, photo.container, photo))

        # We had a rel="alternat" link to the entry which points at
        # the HTML version of the film
        # The URL is of the form: http://host/photo/ID
        # where ID is the id value of the film object
        # that we have just created
        location = member.collection.base_uri + str(photo.ID)
        attrs = {u'href': location, u'type': u'text/html',
                 u'rel': u'alternate'}
        E(u'link', attributes=attrs, namespace=entry.xml_ns,
          prefix=entry.xml_prefix, parent=entry)

        # The rel="edit" link did not know yet about the film ID
        # so we update it here
        # That means we also have to update member.media_id and
        # member.member_id
        edit_link = entry.filtrate(lookup_links, rel=u'edit')
        if edit_link:
            edit_link = edit_link[0]
            href = edit_link.get_attribute('href')
            # This extracts the last part of the URL
            resource_id = urlparse(href.xml_text)[2].rsplit('/', 1)[-1]
            member_id = u'%d.%s' % (photo.ID, member.collection.member_extension)
            href.xml_text = href.xml_text.replace(resource_id, member_id)
            member.media_id = member.member_id = member_id
             
        # We don't want to make a photoraph which as no image attached publicly
        # available in the cache. At the current stage we do not have the
        # image data yet and therefore we do not put this photograph in our
        # cache.
        
        return member, content

    # Same as above except that it provides
    # the member as it exists within the storage
    #�and the member generated from the PUT content
    #�This allows you to compare the two or do whatever
    #�is useful to your needs.
    def on_update(self, existing_member, new_member, new_content):
        entry = new_member.atom.xml_root
        
        title = unicode(entry.get_child('title', entry.xml_ns))
        description = unicode(entry.get_child('summary', entry.xml_ns))
        
        id = extract_uuid_from_urn(unicode(entry.id))
        photo = Photo.fetch_by_uuid(id)
        if not photo:
            # This will stop immediatly the processing and return the HTTP error to
            # the client
            raise ResourceOperationException('Could not find photo with UUID %s' % id, 404)
        
        photo.update(title, description)

        # We don't want to make a photoraph which as no image attached publicly
        # available in the cache
        if photo.filename:
            # Update the view cache
            generate_photo_view(photo, update_previous=True)
               
        return new_member, new_content

    # Called before the member is actually removed from
    # the storage
    def on_delete(self, member):
        entry = member.atom.xml_root
        id = extract_uuid_from_urn(unicode(entry.id))
        photo = Photo.fetch_by_uuid(id)
        if photo:
            filename = member.media_id
            extension = mimetypes.guess_extension(member.media_type)
            if extension:
                filename = "%s%s" % (member.media_id, extension)

            # Let's deletd the image data from the filesystem
            tasks.put(DeleteFileTask(conf.photograph.photographs_directory, filename))

            # We need to get the previous and next photograph of the soon-to-be-deleted
            # photograph but we must of course do that before it is deleted
            previous, next = photo.film.previous_and_next(photo)
            
            # Update the view cache
            delete_photo_view(photo)
            photo.delete()

            # Now we can update the cache so that the previous and next
            # photograph points at each other rather than to a deleted one
            if previous:
                generate_photo_view(previous)
            if next:
                generate_photo_view(next)

class PhotoDataHandler(object):
    def __init__(self, member_type):
        # The media-type that this class will handle
        self.member_type = member_type

    # When the client sends us an photograph we do update
    # the atom member and then store the image on or filesystem
    def on_update(self, existing_member, new_member, new_content):
        entry = new_member.atom.xml_root
        
        id = extract_uuid_from_urn(unicode(entry.id))
        photo = Photo.fetch_by_uuid(id)
        if not photo:
            raise ResourceOperationException('Could not find photo with UUID %s' % id, 404)

        extension = mimetypes.guess_extension(new_member.media_type)
        if extension:
            new_member.media_id = "%s%s" % (new_member.media_id, extension)
        photo.update(photo.name, photo.legend, photo.filename, photo.mediatype,
                     photo.width, photo.height, photo.filesize)
        tasks.put(UpdateFileTask(conf.photograph.photographs_directory, new_member.media_id, new_content))

        # Update the view cache
        generate_photo_view(photo, update_previous=True)
               
        # Let's update the atom:updated and app:edited values
        isodate = get_isodate()
        updated = entry.get_child('updated', ns=entry.xml_ns)
        if updated:
            updated.xml_text = isodate
            
        edited = entry.get_child('edited', ns=ATOMPUB_NS)
        if edited:
            edited.xml_text = isodate

        return new_member, entry.xml()

    def on_delete(self, member):
        entry = member.atom.xml_root
        id = extract_uuid_from_urn(unicode(entry.id))
        photo = Photo.fetch_by_uuid(id)
        if photo:
            previous, next = photo.film.previous_and_next(photo)

            filename = member.media_id
            extension = mimetypes.guess_extension(member.media_type)
            if extension:
                filename = "%s%s" % (member.media_id, extension)
            
            # Update the view cache
            delete_photo_view(photo)
            photo.delete()
            
            if previous:
                generate_photo_view(previous)
            if next:
                generate_photo_view(next)
