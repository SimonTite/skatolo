# -*- coding: utf-8 -*-

from urlparse import urlparse
from bridge.filter.atom import lookup_links
from bridge import Element as E
from amplee.utils import extract_uuid_from_urn

from models import Photoblog, Album
from lib import conf
from lib.cachetools import generate_page_view, delete_page_view
from lib.taskhandler import tasks, UpdateFeedTask, \
     DeleteFeedTask

__all__ = ['AlbumAtomHandler']

class AlbumAtomHandler(object):
    def __init__(self, member_type):
        # The media-type that this class will handle
        # In this case application/atom+xml
        self.member_type = member_type

    # Called when the media resource is being requested
    def on_get_content(self, member, content, content_type):
        id = extract_uuid_from_urn(unicode(member.atom.id))
        album = Album.fetch_by_uuid(id)
        if not album:
            # It is possible that the album has been
            # removed from the database and we don't want
            # amplee to serve the resource anymore
            raise ResourceOperationException('Gone', 410)
        
        return member, content, content_type

    # Called when the entry member is being requested
    def on_get_atom(self, member):
        id = extract_uuid_from_urn(unicode(member.atom.id))
        album = Album.fetch_by_uuid(id)
        if not album:
            raise ResourceOperationException('Gone', 410)
        
        return member, member.atom.xml(), self.member_type.media_type

    # Called upon creation of a new member
    # It provides the automatically generated member
    # (see amplee.atompub.member.*) and the
    # content sent within the request.
    # This should return the member and the content
    # again but in between you can modify both of
    # them before they get stored in the storage
    def on_create(self, member, content):
        # Get an handle to the root element of our atom entry
        entry = member.atom.xml_root

        # Extracts the UUID part of the URN
        id = extract_uuid_from_urn(unicode(entry.id))
        title = unicode(entry.get_child('title', entry.xml_ns))
        description = unicode(entry.get_child('summary', entry.xml_ns))
        authors = entry.get_children('author', entry.xml_ns)
        author = None
        if authors:
            author = unicode(authors[0].get_child('name', entry.xml_ns))
        content = u''

        # Let's create a new Album object based on the
        # information provided by the Atom entry
        album = Album()
        album.create(Photoblog.current(), title, author, description, content, uuid=id)

        # Let's updatet he public atom feed of albums
        tasks.put(UpdateFeedTask(conf.album, album))
        
        # We had a rel="alternate" link to the entry which points at
        # the HTML version of the album
        # The URL is of the form: http://host/album/ID
        # where ID is the id value of the album object
        # that we have just created
        location = member.collection.base_uri + str(album.ID)
        attrs = {u'href': location, u'type': u'text/html',
                 u'rel': u'alternate'}
        E(u'link', attributes=attrs, namespace=entry.xml_ns,
          prefix=entry.xml_prefix, parent=entry)

        # The rel="edit" atom link is what make an atom entry a member resource
        # for an APP service. The link's href attribute contains the URI
        # to which the client can use the GET, HEAD, PUT and DELETE methods.
        # This URI is the URI of the member resource and if the media-type
        # of the request is application/atom+xml the representation of
        # that resource is an Atom entry.

        # The rel="edit" link did not know yet about the album ID
        # so we update it here
        # That means we also have to update member.media_id and
        # member.member_id
        # The next call looks for an existing rel="edit" atom link
        edit_link = entry.filtrate(lookup_links, rel=u'edit')
        if edit_link:
            edit_link = edit_link[0]
            href = edit_link.get_attribute('href')
            # This extracts the last part of the URL
            resource_id = urlparse(href.xml_text)[2].rsplit('/', 1)[-1]
            member_id = u'%d.%s' % (album.ID, member.collection.member_extension)
            href.xml_text = href.xml_text.replace(resource_id, member_id)

            # We update the member.media_id and member.member_id. The former
            # is the internal identifier used by Amplee to identify the member
            # resource (atom entry). The latter serves to identify any
            # media-resource potentially associated.
            # Here we set them to the same value.
            member.media_id = member.member_id = member_id

        # We update the album page view in the cache
        generate_page_view(album)

        # We return our modified member so that amplee can stores the
        # updated version
        return member, content

    # Same as above except that it provides
    # the member as it exists within the storage
    #�and the member generated from the PUT content
    #�This allows you to compare the two or do whatever
    #�is useful to your needs.
    def on_update(self, existing_member, new_member, new_content):
        entry = new_member.atom.xml_root
        
        title = unicode(entry.get_child('title', entry.xml_ns))
        description = unicode(entry.get_child('summary', entry.xml_ns))
        authors = entry.get_children('author', entry.xml_ns)
        author = None
        if authors:
            author = unicode(authors[0].get_child('name', entry.xml_ns) or '')
        content = u''
        
        id = extract_uuid_from_urn(unicode(entry.id))
        album = Album.fetch_by_uuid(id)
        if not album:
            raise ResourceOperationException('Gone', 410)
        album.update(title, author, description, content)
        generate_page_view(album)
        tasks.put(UpdateFeedTask(conf.album, album))
        return new_member, new_content

    # Called before the member is actually removed from
    # the storage
    def on_delete(self, member):
        id = extract_uuid_from_urn(unicode(member.atom.id))
        album = Album.fetch_by_uuid(id)
        if album:
            # Here we perfom a delete cascade of all the film entries
            # assiociated with our album

            # First of all we get the section of our application config
            # we should use for this task
            # For example here we 'link_to' the the [film] section
            section = conf.get_section(conf.album.link_to)
            
            # Then we retrieve the collection associated with the films
            collection = member.collection.workspace.get_collection(section.atompub_collection_name)
            
            # Then for each film associated with our album
            # we perform a delete which will cascade as well on each
            # photograph linked to the film
            for child in album.children:
                member_id, media_id = collection.convert_id(str(child.ID))
                child_member = collection.get_member(member_id)
                if child_member:
                    collection.dispatch('on_delete', child_member.media_type, child_member)
                    collection.prune(member_id, media_id)

            # We remove the cache item fo this album
            delete_page_view(album)
            
            # Now we can safely remove the atom entry associated with our album
            # from the main feed
            tasks.put(DeleteFeedTask(conf.album, album.ID))
            
            # and our album of course
            album.delete()
