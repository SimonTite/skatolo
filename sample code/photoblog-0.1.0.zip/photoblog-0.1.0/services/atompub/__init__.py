# -*- coding: utf-8 -*-

import os.path
from bridge import Element, Attribute
from bridge.common import atom_as_attr, atom_as_list, atom_attribute_of_element

Element.as_list = atom_as_list
Element.as_attribute = atom_as_attr
Attribute.as_attribute_of_element = atom_attribute_of_element

from amplee.handler.store.cp import Service, Store
from amplee.loader import loader, Config

__all__ = ['setup_store']

def load_store():
    """
    Loads into memory our APP store from the configuration file
    """
    from lib import conf
    service, config = loader(os.path.join(conf.app.root_path, 'etc', 'atompub.conf'),
                             encoding=conf.app.encoding, base_path=conf.app.root_path)

    return service, config

def setup_store():
    service, conf = load_store()
    workspace = service.workspaces[0]

    app = Service(service)
    app.albums = Store(workspace.get_collection('albums'), strict=True)
    app.films = Store(workspace.get_collection('films'), strict=True)
    app.photographs = Store(workspace.get_collection('photographs'), strict=True)

    return app

    
