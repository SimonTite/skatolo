# -*- coding: utf-8 -*-

from urlparse import urlparse
from bridge.filter.atom import lookup_links
from bridge import Element as E
from bridge.common import ATOMPUB_NS, THR_NS
from amplee.utils import extract_uuid_from_urn
from amplee.error import ResourceOperationException

from models import Album, Film
from lib import conf
from lib.cachetools import generate_film_view, delete_film_view
from lib.taskhandler import tasks, UpdateFeedTask, \
     DeleteFeedTask, UpdateContainerFeedTask

__all__ = ['FilmAtomHandler']

class FilmAtomHandler(object):
    def __init__(self, member_type):
        # The media-type that this class will handle
        self.member_type = member_type

    # Called when the media resource is being requested
    def on_get_content(self, member, content, content_type):
        id = extract_uuid_from_urn(unicode(member.atom.id))
        film = Film.fetch_by_uuid(id)
        if not film:
            # It is possible tha the film has been
            # removed from the database and we don't want
            # amplee to serve the resource anymore
            raise ResourceOperationException('Gone', 410)
        
        return member, content, content_type

    # Called when the entry member is being requested
    def on_get_atom(self, member):
        id = extract_uuid_from_urn(unicode(member.atom.id))
        film = Film.fetch_by_uuid(id)
        if not film:
            raise ResourceOperationException('Gone', 410)
        
        return member, member.atom.xml(), 'application/atom+xml'

    # Called upon creation of a new member
    # It provides the automatically generated member
    # (see amplee.atompub.member.*) and the
    # content sent within the request.
    # This should return the member and the content
    # again but in between you can modify both of
    # them before they get stored in the storage
    def on_create(self, member, content):
        entry = member.atom.xml_root
        # We need to knwo to which album this film must be added
        # Because we don't want that value to be passed via the URL
        # we look for a <thr:in-reply-to /> element in the Atom entry
        # The element's content is a UUID value identifying
        # the album.
        # If the element is not present we cannot fulfill the request
        # and therefore abort the request now.
        incoming = E.load(content).xml_root
        in_reply_to = incoming.get_child('in_reply_to', THR_NS)
        if in_reply_to is None:
            # This exception will be interpreted by amplee as an abortion
            raise ResourceOperationException('Missing thr:in-reply-to element (RFC 4685)', 400)

        incoming = None
        
        album_uuid = unicode(in_reply_to.get_attribute('ref'))
        album = Album.fetch_by_uuid(album_uuid)
        
        if not album:
            raise ResourceOperationException('No album with UUID %s found' % album_uuid, 400)
        
        id = extract_uuid_from_urn(unicode(entry.id))
        title = unicode(entry.get_child('title', entry.xml_ns))
        description = unicode(entry.get_child('summary', entry.xml_ns))

        # Let's create a new Film object based on the
        # information provided by the Atom entry
        film = Film()
        film.create(album, title, description, uuid=id)

        tasks.put(UpdateFeedTask(conf.film, film))
        tasks.put(UpdateContainerFeedTask(conf.album, film.container, film))

        # We had a rel="alternat" link to the entry which points at
        # the HTML version of the film
        # The URL is of the form: http://host/film/ID
        # where ID is the id value of the film object
        # that we have just created
        location = member.collection.base_uri + str(film.ID)
        attrs = {u'href': location, u'type': u'text/html',
                 u'rel': u'alternate'}
        E(u'link', attributes=attrs, namespace=entry.xml_ns,
          prefix=entry.xml_prefix, parent=entry)

        # The rel="edit" link did not know yet about the film ID
        # so we update it here
        # That means we also have to update member.media_id and
        # member.member_id
        edit_link = entry.filtrate(lookup_links, rel=u'edit')
        if edit_link:
            edit_link = edit_link[0]
            href = edit_link.get_attribute('href')
            # This extracts the last part of the URL
            resource_id = urlparse(href.xml_text)[2].rsplit('/', 1)[-1]
            member_id = u'%d.%s' % (film.ID, member.collection.member_extension)
            href.xml_text = href.xml_text.replace(resource_id, member_id)
            member.media_id = member.member_id = member_id

        generate_film_view(film)
                    
        return member, content

    # Same as above except that it provides
    # the member as it exists within the storage
    #�and the member generated from the PUT content
    #�This allows you to compare the two or do whatever
    #�is useful to your needs.
    def on_update(self, existing_member, new_member, new_content):
        entry = new_member.atom.xml_root
        
        title = unicode(entry.get_child('title', entry.xml_ns))
        description = unicode(entry.get_child('summary', entry.xml_ns))
        
        id = extract_uuid_from_urn(unicode(entry.id))
        film = Film.fetch_by_uuid(id)
        if not film:
            raise ResourceOperationException('Gone', 410)
        
        film.update(title, description)
        generate_film_view(film)
        tasks.put(UpdateFeedTask(conf.film, film))
        
        return new_member, new_content

    # Called before the member is actually removed from
    # the storage
    def on_delete(self, member):
        id = extract_uuid_from_urn(unicode(member.atom.id))
        film = Film.fetch_by_uuid(id)
        if film:
            section = conf.get_section(conf.film.link_to)
            collection = member.collection.workspace.get_collection(section.atompub_collection_name)
            for child in film.children:
                member_id, media_id = collection.convert_id(str(child.ID))
                child_member = collection.get_member(member_id)
                if child_member:
                    collection.dispatch('on_delete', child_member.media_type, child_member)
                    collection.prune(member_id, media_id)

            delete_film_view(film)
            tasks.put(DeleteFeedTask(conf.film, film.ID))
            film.delete()
