# -*- coding: utf-8 -*-

__authors__ = ["Sylvain Hellegouarch (sh@defuze.org)"]
__version__ = "0.1.0"
__copyright__ = """
Copyright (c) 2006, 2007, Sylvain Hellegouarch
All rights reserved.
"""
__license__ = """
Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

     * Redistributions of source code must retain the above copyright notice,
       this list of conditions and the following disclaimer.
     * Redistributions in binary form must reproduce the above copyright notice,
       this list of conditions and the following disclaimer in the documentation
       and/or other materials provided with the distribution.
     * Neither the name of Sylvain Hellegouarch nor the names of his contributors
       may be used to endorse or promote products derived from this software
       without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""
import os, os.path
import cherrypy
from lib import conf, taskhandler

current_dir = os.path.abspath(os.path.dirname(__file__))
task_handler = taskhandler.TaskHandler()

def make_absolute_path():
    base_path = conf.app.root_path
    conf.app.design_base_path = os.path.join(base_path, conf.app.design_base_path)
    conf.cache.feed_cache_directory = os.path.join(base_path, conf.cache.feed_cache_directory)
    conf.cache.content_base_directory = os.path.join(base_path, conf.cache.content_base_directory)
    conf.photograph.photographs_directory = os.path.join(base_path, conf.photograph.photographs_directory)

def setup(options):
    conf.from_ini(os.path.join(current_dir, 'etc', 'application.conf'))
    make_absolute_path()
    
    # Update the CherryPy global configuration
    cherrypy.config.update(os.path.join(current_dir, 'etc', 'http.conf'))

    # Setup logging related to the application itself
    task_handler.enable_logging(os.path.join(current_dir, 'var', 'logs', 'photoblog.log'))

    # Enable cache logging as well
    from lib.cachemanager import feed_cache
    feed_cache.enable_logging(os.path.join(current_dir, 'var', 'logs', 'cache.log'))

    # Setup the storage and the design
    from lib import storage, design
    if options.log_sql:
        from lib.logger import Logger
        path = os.path.join(current_dir, 'var', 'logs', 'sql.log')
        logger = Logger(name='sql.logger', path=path, stderr=True)
        storage.log_sql(logger)
    storage.setup()
    design.setup()
    
    # Construct the published trees
    import controllers
    blog_app = controllers.construct_app()
    
    import services
    services_app = services.construct_app()

    # A bit of cleanup could have been requested
    if options.empty_cache:
        feed_cache.reset(subdirs=['content'], ext='xml')
        feed_cache.reset(subdirs=['albums', 'films', 'photographs'])

    if options.init_storage:
        storage.initialize()
        
    if options.reset_storage:
        storage.reset()

    # Mount the applications on the '/' prefix
    engine_conf_path = os.path.join(current_dir, 'etc', 'engine.conf')
    photoblog_app = cherrypy.tree.mount(blog_app, '/', config=engine_conf_path)
    photoblog_app.merge(controllers.blog_conf)
    service_app = cherrypy.tree.mount(services_app, '/services', config=engine_conf_path)
    service_app.merge(services.services_conf)

def parse_commandline():
    from optparse import OptionParser
    parser = OptionParser()
    parser.add_option("-i", "--init-storage", dest="init_storage",
                      help="initialize the storage", action="store_true")
    parser.add_option("-r", "--reset-storage", dest="reset_storage",
                      help="reset data within the storage", action="store_true")
    parser.add_option("-e", "--empty-cache", dest="empty_cache",
                      help="empty the cache", action="store_true")
    parser.add_option("-g", "--remove-logs", dest="remove_logs",
                      help="remove existing logs", action="store_true")
    parser.add_option("-q", "--log-sql", dest="log_sql",
                      help="log SQL queries to stderr", action="store_true")
    parser.add_option("-l", "--enable-stderr-logging", dest="log_to_stderr",
                      help="enable photoblog related logging to stderr in addition to the file",
                      action="store_true")
    parser.add_option("-t", "--test-loading", dest="test_loading",
                      help="don't run the server but simply try to load the application", action="store_true")
    parser.add_option("-s", "--https", dest="use_https",
                      help="use HTTPS instead of HTTP", action="store_true")
    (options, args) = parser.parse_args()

    return options

def start_handlers():
    taskhandler.start(task_handler)
    
def stop_handlers():
    taskhandler.stop(task_handler)

def run(options):
    if options.use_https:
        CA = os.path.join(current_dir, 'etc', 'server.crt')
        KEY = os.path.join(current_dir, 'etc', 'server.key')
        cherrypy.server.ssl_certificate = CA
        cherrypy.server.ssl_private_key = KEY
    cherrypy.server.quickstart()
    # Start the CherryPy engine
    cherrypy.engine.on_start_engine_list.append(start_handlers)
    cherrypy.engine.on_stop_engine_list.append(stop_handlers)
    cherrypy.engine.start()
    

if __name__ == '__main__':
    options = parse_commandline()
    
    if options.remove_logs:
        import glob
        logs = glob.glob(os.path.join(current_dir, 'var', 'logs', '*.log'))
        for _ in logs:
            os.unlink(_)

    setup(options)
    if not options.test_loading:
        run(options)
