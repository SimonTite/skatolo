# -*- coding: utf-8 -*-

import os
import os.path
import glob

from lib import conf
from lib.logger import Logger

class FeedCacheManager(object):
    """Simply handles operations to the cache itself"""
    def __init__(self):
        self.logger = None

    def _log(self, msg):
        if self.logger:
            self.logger.log(msg)
        
    def reset(self, subdirs, ext='atom'):
        if not subdirs:
            return
        
        subdirs_ = []
        for subdir in subdirs:
            subdirs_.append(os.path.normpath(os.path.join(conf.cache.feed_cache_directory, subdir)))
        subdirs = subdirs_[:]

        for subdir in subdirs:
            self._log("CACHE: Emptying %s" % subdir)
            files = glob.glob(os.path.join(subdir, '*.%s' % ext))
            try:
                for f in files:
                    os.unlink(f)
            except IOError:
                self._log("CACHE: Could not remove file from cache: %s" % self.logger.format_exc())
                
            try:
                if os.path.exists(subdir):
                    os.removedirs(subdir)
            except IOError:
                self._log("CACHE: Could not remove directory from cache: %s" % self.logger.format_exc())

            try:
                os.mkdir(subdir)
            except IOError:
                self._log("CACHE: Could not create directory: %s" % self.logger.format_exc())

    def enable_logging(self, path):
        self.logger = Logger(name='cache.logger', path=path, stderr=False)

    def get_path(self, target, extra_dir=None):
        return os.path.normpath(os.path.join(conf.cache.feed_cache_directory, extra_dir or '',
                                             "%s.atom" % target))

    def exists(self, target, extra_dir=None):
        return os.path.exists(self.get_path(target, extra_dir))

    def get_content(self, target, path=None):
        if not path and target:
            path = self.get_path(target)
        return file(path, 'rb').read()
    
    def update(self, target, content, extra_dir=None):
        path = self.get_path(target, extra_dir=extra_dir)
        self._log("CACHE: Updating %s" % path)
        file(path, 'wb').write(content)

    def remove(self, path):
        try:
            self._log("CACHE: Removing %s" % path)
            os.unlink(path)
        except IOError:
            self._log("CACHE: Could not remove %s" % self.logger.format_exc())
        
feed_cache = FeedCacheManager()

__all__ = ['feed_cache']
