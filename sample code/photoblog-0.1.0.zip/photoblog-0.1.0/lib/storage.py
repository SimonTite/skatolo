# -*- coding: utf-8 -*-

import dejavu
arena = dejavu.Arena()

__all__ = ['arena', 'setup', 'log_sql', 'initialize', 'reset']

from models import Photoblog, Album, Film, Photo
from lib.taskhandler import tasks, UpdateFeedTask

def setup():
    # avoid cross imports
    from lib import conf
    # Some dejavu backend requires that the setting keys are capitalized
    capitalize = conf.get('storage', 'capitalize', True)
    values = conf.get_all_values('storage', capitalize=capitalize)
    arena.add_store("main", "%s" % (conf.storage.type), values)
    arena.register_all(globals())

def log_sql(logger=None):
    if logger:
        arena.log = logger.log
    arena.logflags += dejavu.logflags.SQL
    
def initialize():
    # Drop any existing tables
    for cls in (Photoblog, Album, Film, Photo):
        if arena.has_storage(cls):
            arena.drop_storage(cls)

    # Create the tables
    for cls in (Photoblog, Album, Film, Photo):
        arena.create_storage(cls)
        
def reset():
    from lib import conf
    from lib.cachetools import generate_page_view
    blog = Photoblog()
    blog.create(u"photoblog", u"Demo Photoblog")
    album = Album()
    album.create(blog, u"Photoblog demo album",
                 u"photoblog-demo-album",
                 u"Photoblog demo user",
                 u"This is a simple demo album for you to test",
                 u"")
    generate_page_view(album)
    tasks.put(UpdateFeedTask(conf.album, album))
    
