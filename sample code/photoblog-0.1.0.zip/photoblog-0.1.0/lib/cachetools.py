# -*- coding: utf-8 -*-

import os
from lib import conf
from lib.taskhandler import tasks, UpdateFileTask, DeleteFileTask
from kid import Template, XHTMLSerializer

__all__ = ['generate_page_view', 'generate_film_view',
           'delete_page_view', 'delete_film_view',
           'delete_photo_view', 'generate_photo_view']

##############################################################
# Internal helpers. Not a public API.
##############################################################
def serialize(template, params):
    path = os.path.normpath(os.path.join(conf.app.design_base_path, template + '.kid'))
    template = Template(file=path, **params)
    serializer = XHTMLSerializer(encoding=conf.app.encoding, decl=False)
    content = template.serialize(output=serializer)
    return content

def _get_params_from_album(album, ext='xml'):
    current_photo = previous_photo = next_photo = None
    film = album.first_film
    filename = 'album-%d' % album.ID
    if film:
        current_photo = film.first_photo
        if current_photo:
            previous_photo, next_photo = film.previous_and_next(current_photo)
            if previous_photo: previous_photo = str(previous_photo.ID)
            if next_photo: next_photo = str(next_photo.ID)
    
    return "%s.%s" % (filename, ext), {'album': album, 'film': film, 'current_photo': current_photo,
                                       'previous_photo': previous_photo, 'next_photo': next_photo}

def _get_params_from_film(film, ext='xml'):
    current_photo = previous_photo = next_photo = None
    album = film.album
    filename = 'film-%d' % film.ID
    current_photo = film.first_photo
    if current_photo:
        previous_photo, next_photo = film.previous_and_next(current_photo)
        if previous_photo: previous_photo = str(previous_photo.ID)
        if next_photo: next_photo = str(next_photo.ID)
    
    return "%s.%s" % (filename, ext), {'album': album, 'film': film, 'current_photo': current_photo,
                                       'previous_photo': previous_photo, 'next_photo': next_photo}

def _get_params_from_photo(photo, ext='xml'):
    album = photo.album
    film = photo.film
    filename = 'photo-%d' % photo.ID
    previous_photo, next_photo = film.previous_and_next(photo)
    if previous_photo: previous_photo = str(previous_photo.ID)
    if next_photo: next_photo = str(next_photo.ID)
    
    return "%s.%s" % (filename, ext), {'album': album, 'film': film, 'current_photo': photo,
                                       'previous_photo': previous_photo, 'next_photo': next_photo}

##############################################################
# Public API of the cachetools module
##############################################################
def generate_page_view(album, template='index', ext='xml'):
    filename, params = _get_params_from_album(album, ext=ext)
    content = serialize(template, params)
    directory = os.path.join(conf.cache.content_base_directory,
                             conf.content.cache_directory)
    tasks.put(UpdateFileTask(directory, filename, content))
    if album.ID == album.photoblog.last_album.ID:
        tasks.put(UpdateFileTask(directory, "home.%s" % ext, content))

def delete_page_view(album, ext='xml'):
    directory = os.path.join(conf.cache.content_base_directory,
                             conf.content.cache_directory)
    filename, params = _get_params_from_album(album, ext=ext)
    tasks.put(DeleteFileTask(directory, filename))

    # If the album we delete was the last album created
    # we have ti rebuild the home page as well
    # There is a risk here to fail if there is no album left
    # in the database... optimist are we :)
    blog = album.photoblog
    last_album = blog.last_album
    if album.ID == last_album.ID:
        previous_album = blog.get_previous_album(last_album)
        if previous_album:
            generate_page_view(previous_album)
    
def generate_film_view(film, template='index', ext='xml'):
    directory = os.path.join(conf.cache.content_base_directory,
                             conf.content.cache_directory)
    filename, params = _get_params_from_film(film, ext=ext)
    content = serialize(template, params)
    tasks.put(UpdateFileTask(directory, filename, content))
    
def delete_film_view(film, ext='xml'):
    directory = os.path.join(conf.cache.content_base_directory,
                             conf.content.cache_directory)
    filename, params = _get_params_from_film(film, ext=ext)
    tasks.put(DeleteFileTask(directory, filename))
    blog = film.album.photoblog
    last_album = blog.last_album
    if film.album.ID == last_album.ID:
        generate_page_view(film.album)
    
def delete_photo_view(photo, ext='xml'):
    """Deletes from the cache the current representation of the
    provided photograph object.
    """   
    # Cache directory containing the XML files resulting from
    # our transformations
    directory = os.path.join(conf.cache.content_base_directory,
                             conf.content.cache_directory)
    filename, params = _get_params_from_photo(photo)
    # First let's make sure we remove the cache item for our photo
    tasks.put(DeleteFileTask(directory, filename))
    blog = photo.album.photoblog
    last_album = blog.last_album
    if photo.album.ID == last_album.ID:
        generate_page_view(photo.album)
        
def generate_photo_view(photo, template='index', ext='xml',
                        update_previous=False, update_next=False):
    """Generates the view of a photograph based on the template provided in parameter.
    If 'update_previous' and 'update_next' are set to True the previous and next
    cached photograph item will also be updated to reflect any potential modification.
    """
    # First let's find the base directory of the content cache 
    directory = os.path.join(conf.cache.content_base_directory,
                             conf.content.cache_directory)

    # Now let's generate the cached value of our provided photo
    # Set the parameters used by the templating engine to populate data
    filename, params = _get_params_from_photo(photo)
    content = serialize(template, params)    
    tasks.put(UpdateFileTask(directory, filename, content))

    previous, next = photo.film.previous_and_next(photo)

    generate_page_view(photo.album, template=template, ext=ext)
    generate_film_view(photo.film, template=template, ext=ext)
        
    # When requested and if it exists we also update the previous photograph cached item
    # so that the link to the next photograph points at the photograph provided
    # in parameter
    if update_previous and previous:
        filename, params = _get_params_from_photo(previous)
        content = serialize(template, params)
        tasks.put(UpdateFileTask(directory, filename, content))

    # We perform the same operation for the next cached item if requested
    if update_next and next:
        filename, params = _get_params_from_photo(next)
        content = serialize(template, params)
        tasks.put(UpdateFileTask(directory, filename, content))
