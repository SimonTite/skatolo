# -*- coding: utf-8 -*-

from amplee.loader import Config
conf = Config()

def lesser_comparer(a, b):
    if a[1] < b[1]:
        return 1
    elif a[1] == b[1]:
        return 0
    return -1

def greater_comparer(a, b):
    if a[1] > b[1]:
        return 1
    elif a[1] == b[1]:
        return 0
    return -1
    
__all__ = ['conf']
