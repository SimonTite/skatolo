# -*- coding: utf-8 -*-

import os, os.path
import Queue
import sys, traceback
import threading
from bridge import Element as E
from bridge.common import ATOM10_PREFIX, ATOM10_NS
from bridge.filter.atom import lookup_entry

from lib import conf
from lib.cachemanager import feed_cache
from lib.logger import Logger

__all__ = ['tasks', 'start', 'stop', 'TaskHandler', 'UpdateContainerFeedTask',
           'UpdateFeedTask', 'UpdateFileTask', 'DeleteFileTask',
           'DeleteFeedTask']

# This queue is used by the application to add new task to be
# run via the task handler. This means that each task is run
# without concurrent access
tasks = Queue.Queue()

def start(handler):
    """Starts the given handler thread"""
    handler.start()
    
def stop(handler):
    """Waits for the handler thread to finish"""
    if handler.isAlive():
        handler.stop()
        handler.join()

##################################################################
# Tasks handler
##################################################################
class TaskHandler(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.logger = None

    def _log(self, msg):
        if self.logger:
            self.logger.log(msg)
    
    def enable_logging(self, path, stderr=False):
        self.logger = Logger(name='photoblog.logger', path=path,
                             stderr=stderr)

    def stop(self):
        """By putting a None value in the tasks queue we inform the
        task handler thread we want to terminate"""
        tasks.put(None)
        
    def run(self):
        while 1:
            # Simply block until a task is available in the queue
            # and then run it
            # If the retrieved task is None we exit the loop
            task = tasks.get() or None
            if task:
                try:
                    self._log("TASK: %s" % repr(task))
                    task.run()
                except:
                    exc = sys.exc_info()
                    exc = "".join(traceback.format_exception(*exc))
                    self._log("TASK: %s" % exc)
            else:
                break

##################################################################
# Tasks
##################################################################
class UpdateFeedTask(object):
    def __init__(self, conf, unit):
        self.conf = conf
        self.unit = unit
        
    def __repr__(self):
        return "<UpdateFeedTask for %s on id %d>" % (self.unit.__class__, self.unit.ID)

    def update_feed(self):
        """Update the feed associated to the unit"""
        if feed_cache.exists(self.unit.uuid):
            content = feed_cache.get_content(self.unit.uuid)
            feed = E.load(content).xml_root
            for child in ('title', 'author', 'updated', 'rights'):
                element = feed.get_child(child, feed.xml_ns)
                if element:
                    del element
        else:
            feed = E(u'feed')
            E(u'id', content=u'urn:uuid:%s' % self.unit.uuid, parent=feed)
            E(u'link', attributes={u'href': unicode('%s%s%d.atom' % (conf.app.base_service_url, self.conf.feed_uri,
                                                                    self.unit.ID)),
                                   u'rel': u'self', u'type': u'application/atom+xml;type=feed'}, parent=feed)
            E(u'link', attributes={u'href': unicode('%s%s%d' % (conf.app.base_service_url, self.conf.feed_uri,
                                                                self.unit.ID)),
                                   u'rel': u'alternate', u'type': u'text/html'}, parent=feed)
           
        E(u'title', content=self.unit.title, parent=feed)
        author = E(u'author', parent=feed)
        E(u'name', content=self.unit.author, parent=feed)
        if conf.app.copyright:
            E(u'rights', content=unicode(conf.app.copyright), attributes={u'type': u'text'}, parent=feed)
        feed.update_prefix(ATOM10_PREFIX, None, ATOM10_NS, update_attributes=False)
        
        return feed

    def run(self):
        feed = self.update_feed()
        feed_cache.update(str(self.unit.ID), feed.xml(indent='yes'), extra_dir=self.conf.cache_directory)

class DeleteFeedTask(object):
    def __init__(self, conf, unit_id):
        self.conf = conf
        self.unit_id = unit_id

    def __repr__(self):
        return "<DeleteFeedTask (ID:%d)" % (self.unit_id,)

    def run(self):
        unit_id = str(self.unit_id)
        if feed_cache.exists(unit_id, extra_dir=self.conf.cache_directory):
            feed_cache.remove(feed_cache.get_path(unit_id, extra_dir=self.conf.cache_directory))

class UpdateContainerFeedTask(object):
    def __init__(self, conf, container, unit):
        self.conf = conf
        self.container = container
        self.unit = unit

    def __repr__(self):
        return "<UpdateContainerFeedTask for %s (ID:%d) on %s (ID:%d)" % (self.container.__class__,
                                                                          self.container.ID,
                                                                          self.unit.__class__,
                                                                          self.unit.ID)

    def update_container(self):
        """Update the feed containing the entry representing this unit"""
        if not feed_cache.exists(self.container.uuid):
            feed = E(u'feed')
            E(u'id', content=u'urn:uuid:%s' % self.container.uuid, parent=feed)
            E(u'link', attributes={u'href': unicode('%s%s%d' % (conf.app.base_service_url, self.conf.feed_uri,
                                                                self.container.ID)),
                                   u'rel': u'self', u'type': u'application/atom+xml;type=feed'}, parent=feed)
            E(u'link', attributes={u'href': unicode('%s%s%d' % (conf.app.base_service_url, self.conf.feed_uri,
                                                                self.container.ID)),
                                   u'rel': u'alternate', u'type': u'text/html'}, parent=feed)
        else:
            content = feed_cache.get_content(self.container.uuid)
            feed = E.load(content).xml_root
            for child in ('title', 'author', 'updated', 'rights'):
                element = feed.get_child(child, feed.xml_ns)
                if element:
                    del element

        # Do we already have an entry with that atom:id?
        # If yes we just remove it entirely rather than updating its parts
        # Since the feed is read-only and should only be modified
        # by the application we shall not loose information
        entry = feed.filtrate(lookup_entry, id=self.unit.uuid)
        if entry:
            entry.forget()

        entry = self.unit.to_atom_entry()
        feed.xml_children.append(entry)
        entry.xml_parent = feed

        return feed
        
    def run(self):
        feed = self.update_container()
        feed_cache.update(str(self.container.ID), feed.xml(indent='yes'), extra_dir=self.conf.cache_directory)
                    
class UpdateFileTask(object):
    def __init__(self, directory, filename, data):
        self.directory = directory
        self.filename = str(filename)
        self.data = data

    def __repr__(self):
        return "<UpdateFileTask for %s>" % os.path.join(self.directory, self.filename)

    def run(self):
        if not self.data:
            return
        
        if not os.path.exists(self.directory):
            os.mkdir(self.directory)

        path = os.path.join(self.directory, self.filename)
        file(path, 'wb').write(self.data)

class DeleteFileTask(object):
    def __init__(self, directory, filename):
        self.directory = directory
        self.filename = str(filename)

    def __repr__(self):
        return "<DeleteFileTask for %s>" % os.path.join(self.directory, self.filename)
    
    def run(self):
        path = os.path.join(self.directory, self.filename)
        if os.path.exists(path):
            os.unlink(path)
        
    
