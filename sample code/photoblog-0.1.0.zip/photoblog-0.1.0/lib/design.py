# -*- coding: utf-8 -*-

import os.path
import kid
import cherrypy

__all__ = ['setup']

def generate(path=None, template=None, type='html', params=None):
    if path and template and isinstance(params, dict):
        path = os.path.normpath(os.path.join(path, template + '.kid'))
        template = kid.Template(file=path, **params)
        return template.generate(output=type)

def transform(path=None, template=None, type='html'):
    params = cherrypy.response.body
    cherrypy.response.body = generate(path, template, type, params)

def setup():
    # Attach our Design tool to the CherryPy default toolbox
    cherrypy.tools.design = cherrypy.Tool("before_finalize", transform)
