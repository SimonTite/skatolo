# -*- coding: utf-8 -*-

import sys
import traceback
import logging
from logging import FileHandler, StreamHandler
from datetime import datetime
import rfc822

__all__ = ['Logger']

_pattern = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"'

class Logger(object):
    def __init__(self, name, path=None, stderr=True):
        logger = logging.getLogger(name)
        logger.setLevel(logging.DEBUG)
        
        logfmt = logging.Formatter("%(message)s")
        if path:
            h = FileHandler(path)
            h.setFormatter(logfmt)
            logger.addHandler(h)
            
        if stderr:
            h = StreamHandler(sys.stderr)
            h.setFormatter(logfmt)
            logger.addHandler(h)

        self.logger = logger
        
    def log(self, message):
        self.logger.log(logging.INFO, '%s %s' % (self.format_now(), message))
    
    def format_now(self):
        # from CherryPy
        now = datetime.now()
        month = rfc822._monthnames[now.month - 1].capitalize()
        return ('[%02d/%s/%04d:%02d:%02d:%02d]' %
                (now.day, month, now.year, now.hour, now.minute, now.second))

    def format_exc(self, exc=None):
        # stolen from CherryPy
        """Return exc (or sys.exc_info if None), formatted."""
        if exc is None:
            exc = sys.exc_info()
        if exc == (None, None, None):
            return ""
        return "".join(traceback.format_exception(*exc))
