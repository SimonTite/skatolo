# -*- coding: utf-8 -*-

import cherrypy
from photoblog import HomeController
from feed import Feed
from album import AlbumController
from photo import PhotoController
from film import FilmController

__all__ = ['construct_app']

def construct_app():
    root = HomeController()
    root.feed = Feed()
    root.album = AlbumController()
    root.film = FilmController()
    root.photograph = PhotoController()
    return root

blog_conf = {}
