# -*- coding: utf-8 -*-

import os.path
import cherrypy
from cherrypy.lib.static import serve_file
from models.photo import Photo
from lib import conf
from lib.cachetools import generate_photo_view

__all__ = ['PhotoController']

class PhotoController:
    @cherrypy.expose
    def default(self, id):
        path = os.path.join(conf.cache.content_base_directory,
                            conf.content.cache_directory, "photo-%s.xml" % id)
        if not os.path.exists(path):
            photo = Photo.fetch(id)
            if not photo:
                raise cherrypy.NotFound()
            # Regenerate the cache value
            generate_photo_view(photo, update_previous=True, update_next=True)
        return serve_file(path, content_type='text/html; charset=%s' % conf.app.encoding)
