# -*- coding: utf-8 -*-

# The AlbumController handles the request to the public
# set of URIs linked to the album entity
# For example: http://host/album/1

# Since we try to mostly serve cached items
# and considering that the management is done
# via our web services this controller is
# pretty simple and straightforward.

import os.path
import cherrypy
from cherrypy.lib.static import serve_file
from models.album import Album
from lib import conf
from lib.cachetools import generate_page_view

__all__ = ['AlbumController']

class AlbumController:
    @cherrypy.expose
    def default(self, id):
        # Let's look for the cached value of the album...
        path = os.path.join(conf.cache.content_base_directory,
                            conf.content.cache_directory, "album-%s.xml" % id)
        if not os.path.exists(path):
            # If the cached item has been deleted
            # we try to regenerate it once
            # This means that the first request hitting this stage of the
            # page handler will be a bit slower than th others
            album = Album.fetch(id)
            if not album:
                # oh well the albim is really gone
                raise cherrypy.NotFound()
            # Regenerate the cache value
            generate_page_view(album)
        # Serve the cache value
        # This function of the CherryPy library will handle the
        # If-Modified-Since header (sec. 14.25 of RFC2616)
        return serve_file(path, content_type='text/html; charset=%s' % conf.app.encoding)
