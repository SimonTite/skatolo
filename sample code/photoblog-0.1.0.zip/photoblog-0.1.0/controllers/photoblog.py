# -*- coding: utf-8 -*-

import os.path
import cherrypy
from cherrypy.lib.static import serve_file
from lib import conf
from models import Photoblog
from lib.cachetools import generate_page_view

__all__ = ['HomeController']

class HomeController:
    @cherrypy.expose
    def index(self):
        path = os.path.join(conf.cache.content_base_directory,
                            conf.content.cache_directory, "home.xml")
        if not os.path.exists(path):
            blog = Photoblog.current()
            album = blog.first_album
            if not album:
                raise cherrypy.NotFound()
            generate_page_view(album)
        return serve_file(path, content_type='text/html; charset=%s' % conf.app.encoding)
