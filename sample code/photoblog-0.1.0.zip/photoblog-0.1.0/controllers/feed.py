# -*- coding: utf-8 -*-

import os.path
import cherrypy
from cherrypy.lib.static import serve_file
from lib import conf

__all__ = ['Feed']

class Feed:
    @cherrypy.expose
    def album(self, id):
        path = os.path.join(conf.cache.feed_cache_directory,
                            conf.album.cache_directory,
                            "%s.atom" % id)
        return serve_file(path, content_type='application/atom+xml;type=feed')

    @cherrypy.expose
    def film(self, id):
        path = os.path.join(conf.cache.feed_cache_directory,
                            conf.film.cache_directory,
                            "%s.atom" % id)
        return serve_file(path, content_type='application/atom+xml;type=feed')

    @cherrypy.expose
    def photograph(self, id):
        path = os.path.join(conf.cache.feed_cache_directory,
                            conf.photograph.cache_directory,
                            "%s.atom" % id)
        return serve_file(path, content_type='application/atom+xml;type=feed')
