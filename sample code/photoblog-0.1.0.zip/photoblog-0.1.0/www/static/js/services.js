function service() {
};

/**************************************************
 * Album entity service
 *************************************************/
function album() {
};

album.prototype.create = function(data) {
   var qs = queryString(data);
   var xmlHttpReq = getXMLHttpRequest();
   xmlHttpReq.open("POST", albumBaseUri, true); 
   xmlHttpReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
   xmlHttpReq.setRequestHeader('Accept', 'application/json');
   xmlHttpReq.setRequestHeader('Connection', 'close');
   var d = sendXMLHttpRequest(xmlHttpReq, qs);
   d.addCallback(function (data) {
      ui.albums.show_success_message();
   });
   d.addErrback(function (data) {
      ui.albums.show_error_message();
   });
};

album.prototype.remove = function(id) {
   if(id != null) {
      var xmlHttpReq = getXMLHttpRequest();
      xmlHttpReq.setRequestHeader('Connection', 'close');
      xmlHttpReq.open("DELETE", albumBaseUri + id, true); 
      var d = sendXMLHttpRequest(xmlHttpReq);
   }
};

album.prototype.update = function(id, data) {
   var qs = queryString(data);
   var xmlHttpReq = getXMLHttpRequest();
   var uri = albumBaseUri + id;
   xmlHttpReq.open("PUT", uri, true); 
   xmlHttpReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
   xmlHttpReq.setRequestHeader('Accept', 'application/json');
    xmlHttpReq.setRequestHeader('Connection', 'close');
   var d = sendXMLHttpRequest(xmlHttpReq, qs);
   d.addCallback(function (data) {
      ui.albums.show_success_message();
   });
   d.addErrback(function (data) {
      ui.albums.show_error_message();
   });
};

album.prototype.fetch = function(id) {
    var xmlHttpReq = getXMLHttpRequest();
    xmlHttpReq.open("GET", albumBaseUri + id, true); 
    xmlHttpReq.setRequestHeader('Accept', 'application/json');
    xmlHttpReq.setRequestHeader('Connection', 'close');
    var d = sendXMLHttpRequest(xmlHttpReq);
    d.addCallback(function (data) {
       var data = evalJSONRequest(data);
       ui.albums.edit(data);
    });
};

album.prototype.fetch_range = function(start, end) {
   var xmlHttpReq = getXMLHttpRequest();
   xmlHttpReq.open("GET", albumsBaseUri.concat(start, "-", end), true); 
   xmlHttpReq.setRequestHeader('Accept', 'application/json');
   xmlHttpReq.setRequestHeader('Connection', 'close');
   var d = sendXMLHttpRequest(xmlHttpReq);
   d.addCallback(function (data) {
      var data = evalJSONRequest(data);
      ui.albums.populate(data);
   });
};

album.prototype.fetch_films = function(album_id) {
   var xmlHttpReq = getXMLHttpRequest();
   xmlHttpReq.open("GET", filmsBaseUri + "?album_id=" + album_id, true); 
   xmlHttpReq.setRequestHeader('Accept', 'application/json');
   xmlHttpReq.setRequestHeader('Connection', 'close');
   var d = sendXMLHttpRequest(xmlHttpReq);
   d.addCallback(function (data) {
      var data = evalJSONRequest(data);
      ui.films.display(data);
   });
};

/**************************************************
 * Film entity service
 *************************************************/
function film() {
};

film.prototype.create = function(data) {
   var qs = queryString(data);
   var xmlHttpReq = getXMLHttpRequest();
   xmlHttpReq.open("POST", filmBaseUri, true); 
   xmlHttpReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
   xmlHttpReq.setRequestHeader('Accept', 'application/json');
   xmlHttpReq.setRequestHeader('Connection', 'close')
   var d = sendXMLHttpRequest(xmlHttpReq, qs);
   d.addCallback(function (data) {
      ui.films.show_success_message();
   });
   d.addErrback(function (data) {
      ui.films.show_error_message();
   });
};

film.prototype.remove = function(id) {
   if(id != null) {
      var xmlHttpReq = getXMLHttpRequest();
      xmlHttpReq.setRequestHeader('Connection', 'close');
      xmlHttpReq.open("DELETE", filmBaseUri + id, true);
      var d = sendXMLHttpRequest(xmlHttpReq);
   }
};

film.prototype.update = function(id, data) {
   var qs = queryString(data);
   var xmlHttpReq = getXMLHttpRequest();
   var uri = filmBaseUri + id;
   xmlHttpReq.open("PUT", uri, true); 
   xmlHttpReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
   xmlHttpReq.setRequestHeader('Accept', 'application/json');
   xmlHttpReq.setRequestHeader('Connection', 'close');
   var d = sendXMLHttpRequest(xmlHttpReq, qs);
   d.addCallback(function (data) {
      ui.films.show_success_message();
   });
   d.addErrback(function (data) {
      ui.films.show_error_message();
   });
};

film.prototype.fetch = function(id) {
    var xmlHttpReq = getXMLHttpRequest();
    xmlHttpReq.open("GET", filmBaseUri + id, true); 
    xmlHttpReq.setRequestHeader('Accept', 'application/json');
    xmlHttpReq.setRequestHeader('Connection', 'close');
    var d = sendXMLHttpRequest(xmlHttpReq);
    d.addCallback(function (data) {
       var data = evalJSONRequest(data);
       ui.films.edit(data);
    });
};

film.prototype.fetch_photos = function(film_id) {
   var xmlHttpReq = getXMLHttpRequest();
   xmlHttpReq.open("GET", photosBaseUri + "?film_id=" + film_id, true); 
   xmlHttpReq.setRequestHeader('Accept', 'application/json');
   xmlHttpReq.setRequestHeader('Connection', 'close');
   var d = sendXMLHttpRequest(xmlHttpReq);
   d.addCallback(function (data) {
      var data = evalJSONRequest(data);
      ui.photos.display(data);
   });
};

/**************************************************
 * Photo entity service
 *************************************************/
function photo() {
};

photo.prototype.create = function(data) {
   var qs = queryString(data);
   var xmlHttpReq = getXMLHttpRequest();
   xmlHttpReq.open("POST", photoBaseUri, true); 
   xmlHttpReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
   xmlHttpReq.setRequestHeader('Accept', 'application/json');
   xmlHttpReq.setRequestHeader('Connection', 'close');
   var d = sendXMLHttpRequest(xmlHttpReq, qs);
   d.addCallback(function (data) {
      ui.photos.show_success_message();
      var data = evalJSONRequest(data);
      ui.photos.show_upload_link(data);
   });
   d.addErrback(function (data) {
      ui.photos.show_error_message();
   });
};

photo.prototype.update = function(id, data) {
   var qs = queryString(data);
   var xmlHttpReq = getXMLHttpRequest();
   var uri = photoBaseUri + id;
   xmlHttpReq.open("PUT", uri, true); 
   xmlHttpReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
   xmlHttpReq.setRequestHeader('Accept', 'application/json');
  xmlHttpReq.setRequestHeader('Connection', 'close');
   var d = sendXMLHttpRequest(xmlHttpReq, qs);
   d.addCallback(function (data) {
      ui.photos.show_success_message();
   });
   d.addErrback(function (data) {
      ui.photos.show_error_message();
   });
};

photo.prototype.fetch = function(id) {
    var xmlHttpReq = getXMLHttpRequest();
    xmlHttpReq.open("GET", photoBaseUri + id, true); 
    xmlHttpReq.setRequestHeader('Accept', 'application/json');
    xmlHttpReq.setRequestHeader('Connection', 'close');
    var d = sendXMLHttpRequest(xmlHttpReq);
    d.addCallback(function (data) {
       var data = evalJSONRequest(data);
       ui.photos.edit(data);
    });
};

photo.prototype.remove = function(id) {
   if(id != null) {
      var xmlHttpReq = getXMLHttpRequest();
      xmlHttpReq.open("DELETE", photoBaseUri + id, true);
      xmlHttpReq.setRequestHeader('Connection', 'close');
      var d = sendXMLHttpRequest(xmlHttpReq);
   }
};

/**************************************************
 * Let's create our singleton for each entity
 * in the services "namespace".
 *************************************************/
service.prototype.albums = new album();
service.prototype.films = new film();
service.prototype.photos = new photo();