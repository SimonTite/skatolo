/**************************************************
 * Javascript module that handles the film entity
 *************************************************/

/* Let's inform Javascript we will be using the
   films function as a constructor */
films.prototype.constructor = films;


/**************************************************
 * Film class definition
 *************************************************/
function films() {
};

/* Retrieve a film based on its identifier which is
   found as the value attribute of the source element
   of the event.
 */
films.prototype.fetch = function(e) {
   e.stop();   
   var film_id = getNodeAttribute(e.src(), 'value');
   services.films.fetch(film_id);
};

/* Create a film based on the data input by the user.
   A quick validation ensures that the input is correct.
 */
films.prototype.create = function(e) {
   if(this.validate()) {
      var data = {'album_id': $('album-id').value, 'title': escape($('film-title').value),
		  'description': escape($('film-desc').value)};
      services.films.create(data);
   }
};

/* Update an existing film based on the data input by the user.
   A quick validation ensures that the input is correct.
 */
films.prototype.update = function(e) {
   if(this.validate()) {
      var data = {'title': escape($('film-title').value), 'description': escape($('film-desc').value)};
      services.films.update($('film-id').value, data);
   }
};

/* Send the message to the REST service that the current film
   can be deleted from the system.
 */
films.prototype.ditch = function(e) {
   e.stop();
   var doit = confirm("Are you sure you want to delete this film?");
   if(doit) {
      services.films.remove($('film-id').value);
      hideElement($('form-manage-photos'));
      hideElement($('form-delete'));
      hideElement($('form-submit'));
   }
};

/* Fetch all the photographs belonging to this film. 
*/
films.prototype.fetch_photos = function(e) {
   e.stop();
   services.films.fetch_photos($('film-id').value);
};

/* Form filled with the values of the film provided in parameter.
 */
films.prototype.edit = function(film) {
   var deleteLink = SPAN({'id': 'form-delete', 'class': 'form-link'}, 'Delete');
   var submitLink = SPAN({'id': 'form-submit', 'class': 'form-link'}, 'Submit');
   var cancelLink = SPAN({'id': 'form-cancel', 'class': 'form-link'}, 'Cancel');
   var managePhotosLink = SPAN({'id': 'form-manage-photos', 'class': 'form-link'}, 'Manage photos');
   
   var successMessage = SPAN({'id': 'form-success', 'class': 'form-success'}, 'Film updated');
   var errorMessage = SPAN({'id': 'form-error', 'class': 'form-error'}, 'An unexpected error occured');
   var titleErrMsg = SPAN({'id': 'form-title-error', 'class': 'form-error'}, 'You must provide a title');
   var descErrMsg = SPAN({'id': 'form-desc-error', 'class': 'form-error'}, 'You must provide a description');
   
   replaceChildNodes($('formoverlay'));
   var filmForm = FORM({'id': 'update-film',  'name': "filmForm"},
		       INPUT({'name': 'id', 'id': 'film-id', 
			      'type': 'hidden', 'value': film['id']}),
		       titleErrMsg,
		       LABEL({'class': 'form-label'}, 'Title:'),
		       INPUT({'class': 'form-input', 'name': 'title', 
			      'id': 'film-title', 'value': unescape(film['title'])}), BR(),
		       descErrMsg,
		       LABEL({'class': 'form-label'}, 'Description:'),
		       TEXTAREA({'class': 'form-textarea', 'name': 'description', 
				 'id': 'film-desc', 'rows': '2'}, unescape(film['description'])), BR(), 
		       successMessage, errorMessage,
		       DIV({'id': 'form-links'},
			   managePhotosLink,
			   deleteLink,
			   submitLink, 
			   cancelLink));

   hideElement(titleErrMsg);
   hideElement(descErrMsg);
   hideElement(errorMessage);
   hideElement(successMessage);
   connect(deleteLink, 'onclick', this, 'ditch');
   connect(managePhotosLink, 'onclick', this, 'fetch_photos');
   connect(submitLink, 'onclick', this, 'update');
   connect(cancelLink, 'onclick', closeOverlayBox);
   appendChildNodes($('formoverlay'), SPAN({'class': 'form-caption'}, 'Edit a film'));
   appendChildNodes($('formoverlay'), BR());
   appendChildNodes($('formoverlay'), filmForm);
};

/* Display the list of films in paramaters as an HTML select element.
   Each entry of the select element is connected to events to perform
   actions on them.
 */
films.prototype.display = function(films) {  
   var create = SPAN({'class': 'infos-action'}, 'Create');
   connect(create, 'onclick', this, 'blank');
   
   var album_id = $('album-id').value;
   replaceChildNodes($('formoverlay'));
   appendChildNodes($('formoverlay'), INPUT({'name': 'id', 'id': 'album-id', 
					     'type': 'hidden', 'value': album_id}));
   if(films.length == 0){
      appendChildNodes($('formoverlay'), SPAN({'class': 'form-caption'}, 'Create a new film'));
      appendChildNodes($('formoverlay'), BR());
      appendChildNodes($('formoverlay'), BR());
      appendChildNodes($('formoverlay'), create);
      return;
   }

   var filmsSelect = SELECT();

   for(var film in films) {
      film = films[film];
      var filmOption = OPTION({'value': film['id']}, film['title']);
      appendChildNodes(filmsSelect, filmOption);
      connect(filmOption, 'onclick', this, 'fetch');
   }
     
   appendChildNodes($('formoverlay'), SPAN({'class': 'form-caption'}, 'Edit or create a film'));
   appendChildNodes($('formoverlay'), BR());
   appendChildNodes($('formoverlay'), BR());
   appendChildNodes($('formoverlay'), SPAN({}, 'Edit: '));
   appendChildNodes($('formoverlay'), filmsSelect);
   appendChildNodes($('formoverlay'), BR());
   appendChildNodes($('formoverlay'), create);
};

/* Simple validation against a form filled with the film information.
 */
films.prototype.validate = function(e) {
   var ready = true;
   hideElement($('form-title-error'));
   hideElement($('form-desc-error'));
   
   if($('film-title').value == '') {
      appear($('form-title-error'));
      ready = false;
   }
   
   if($('film-desc').value == '') {
      appear($('form-desc-error'));
      ready = false;
   }
   
   return ready;
};
   
/* Show the messages indicating a success in creation
   or update.
 */
films.prototype.show_success_message = function() {
   hideElement($('form-title-error'));
   hideElement($('form-desc-error'));
   
   appear($('form-success'));
   fade($('form-submit'));
};
        
/* Show the messages indicating a failure in creation
   or update.
 */
films.prototype.show_error_message = function() {
   hideElement($('form-title-error'));
   hideElement($('form-desc-error'));
   
   appear($('form-error'));
   fade($('form-submit'));
};

/* Create an empty form to handle the creation of a new film.
 */
films.prototype.blank = function(e) {
   var submitLink = SPAN({'id': 'form-submit', 'class': 'form-link'}, 'Submit');
   var cancelLink = SPAN({'id': 'form-cancel', 'class': 'form-link'}, 'Cancel');
   
   var successMessage = SPAN({'id': 'form-success', 'class': 'form-success'}, 'Film created');
   var errorMessage = SPAN({'id': 'form-error', 'class': 'form-error'}, 'An unexpected error occured');
   var titleErrMsg = SPAN({'id': 'form-title-error', 'class': 'form-error'}, 'You must provide a title');
   var descErrMsg = SPAN({'id': 'form-desc-error', 'class': 'form-error'}, 'You must provide a description');

   album_id = $('album-id').value;
   replaceChildNodes($('formoverlay'));
   var filmForm = FORM({'id': 'create-film',  'name': "filmForm"},
		       INPUT({'name': 'id', 'id': 'album-id', 
			      'type': 'hidden', 'value': album_id}),
		       titleErrMsg,
			LABEL({'class': 'form-label'}, 'Title:'),
			INPUT({'class': 'form-input', 'name': 'title', 
			       'id': 'film-title', 'value': ''}), BR(),
			descErrMsg,
			LABEL({'class': 'form-label'}, 'Description:'),
			TEXTAREA({'class': 'form-textarea', 'name': 'description', 
				  'id': 'film-desc', 'rows': '2', 'value': ''}), BR(), 
			successMessage, errorMessage,
			DIV({'id': 'form-links'},
			    submitLink, 
			    cancelLink));
   
   hideElement(titleErrMsg);
   hideElement(descErrMsg);
   hideElement(errorMessage);
   hideElement(successMessage);
   connect(submitLink, 'onclick', this, 'create');
   connect(cancelLink, 'onclick', closeOverlayBox);
   appendChildNodes($('formoverlay'), SPAN({'class': 'form-caption'}, 'Create a new film'));
   appendChildNodes($('formoverlay'), BR());
   appendChildNodes($('formoverlay'), filmForm);
};
   
