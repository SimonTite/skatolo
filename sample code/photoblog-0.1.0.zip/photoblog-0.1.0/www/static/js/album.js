/**************************************************
 * Javascript module that handles the album entity
 *************************************************/

/* Let's inform Javascript we will be using the
   albums function as a constructor */
albums.prototype.constructor = albums;


/**************************************************
 * Album class definition
 *************************************************/
function albums() {
   this.visibility = false;
   this.current = null;
   this.position = 0;
   this.step = 3;
};

/* Moving forward in the list of available albums
   Calls the services module to perform the 
   HTTP request to the REST web service serving
   a range of albums serialized using the Json 
   format */
albums.prototype.forward = function(e) {
   var end = this.position + this.step;
   services.albums.fetch_range(this.position, end);
   this.position = end;
};

/* Moving backward in the list of available albums
   Calls the services module to perform the 
   HTTP request to the REST web service serving
   a range of albums serialized using the Json 
   format. */
albums.prototype.rewind =  function(e) {
   var start = 0;
   var end = this.position;
   if(this.position != 0) {
      start = this.position - this.step;
   }
   services.albums.fetch_range(start, end);
   this.position = start;
};

/* Redirect the user towards the selected album 
 */
albums.prototype.select = function(e) {
   this.current = (e.src().id).substr(6);
   window.location = albumUri + this.current;
};
   
/* Send the message of creating a new album.
   First it validates the input entered by the user
   before using teh services module to perform
   the actual request. 
 */
albums.prototype.create = function(e) {
   if(this.validate()) {
      var data = {'blog_id': '1', 'title': escape($('album-title').value),
		  'author': escape($('album-author').value),
		  'description': escape($('album-desc').value), 'content': escape($('album-content').value)};
      
      services.albums.create(data);
   }
};

/* Fetch an album given its ID. The identifier value is contained
   in the parent node of the source element onto which the event
   happened.
 */
albums.prototype.fetch = function(e) {
   e.stop();
   this.current = (e.src().parentNode.id).substr(6);
   services.albums.fetch(this.current);
};

/* Fetch all the films belonging to the current album.
 */
albums.prototype.fetch_films = function(e) {
   e.stop();
   services.albums.fetch_films($('album-id').value);
};

/* Update an existing album.
   It validates the input before using the services module 
   to perform the HTTP request.
 */
albums.prototype.update = function(e) {
   if(this.validate()) {
      var data = {'title': escape($('album-title').value), 
		  'author': escape($('album-author').value),
		  'description': escape($('album-desc').value), 
		  'content': escape($('album-content').value)};
      
      services.albums.update($('album-id').value, data);
   }
};

/* Display the edit form filled with the album given in parameter.
   It also initializes the different error/succes messages but hide
   them from the display.
 */
albums.prototype.edit = function(album) {
   var submitLink = SPAN({'id': 'form-submit', 'class': 'form-link'}, 'Submit');
   var cancelLink = SPAN({'id': 'form-cancel', 'class': 'form-link'}, 'Cancel');
   var manageFilmsLink = SPAN({'id': 'form-manage-films', 'class': 'form-link'}, 'Manage films');
   
   var successMessage = SPAN({'id': 'form-success', 'class': 'form-success'}, 'Album updated');
   var errorMessage = SPAN({'id': 'form-error', 'class': 'form-error'}, 'An unexpected error occured');
   var titleErrMsg = SPAN({'id': 'form-title-error', 'class': 'form-error'}, 'You must provide a title');
   var authorErrMsg = SPAN({'id': 'form-author-error', 'class': 'form-error'}, 'You must specify the author name');
   var descErrMsg = SPAN({'id': 'form-desc-error', 'class': 'form-error'}, 'You must provide a description');
   
   // We use the CSS overlay technique to create a semi transparent panel
   // on top of the web page. Then we insert our form in that div.
   var albumForm = DIV({'id': 'pageoverlay'}, 
		       DIV({'id': 'outerbox'},
			   DIV({'id': 'formoverlay'},
			       SPAN({'class': 'form-caption'}, 'Edit an album'), BR(),BR(),
			       FORM({'id': 'update-album',  'name':"albumForm"},
				    titleErrMsg,
				    INPUT({'name': 'id', 'id': 'album-id', 
					   'type': 'hidden', 'value': album['id']}),
				    LABEL({'class': 'form-label'}, 'Title:'),
				    INPUT({'class': 'form-input', 'name': 'title', 
					   'id': 'album-title', 'value': unescape(album['title'])}), BR(),
				    authorErrMsg,
				    LABEL({'class': 'form-label'}, 'Author:'),
				    INPUT({'class': 'form-input', 'name': 'author', 
					   'id': 'album-author', 'value': unescape(album['author'])}), BR(),
				    descErrMsg,
				    LABEL({'class': 'form-label'}, 'Description:'),
				    TEXTAREA({'class': 'form-textarea', 'name': 'description', 
					      'id': 'album-desc', 'rows': '2', 'value': ''}, unescape(album['description'])), BR(), 
				    LABEL({'class': 'form-label'}, 'Content:'),
				    TEXTAREA({'class': 'form-textarea', 'name': 'content', 
					      'id': 'album-content', 'rows': '7', 'value': ''}, unescape(album['content'])), BR()),
			       successMessage, errorMessage,
			       DIV({'id': 'form-links'},
				   manageFilmsLink,
				   submitLink, 
				   cancelLink))));

   hideElement(titleErrMsg);
   hideElement(authorErrMsg);
   hideElement(descErrMsg);
   hideElement(errorMessage);
   hideElement(successMessage);
   connect(manageFilmsLink, 'onclick', this, 'fetch_films');
   connect(submitLink, 'onclick', this, 'update');
   connect(cancelLink, 'onclick', closeOverlayBox);
   appendChildNodes($('photoblog'), albumForm);
};

/* Send the message that an album must be deleted from
   the backend.
 */
albums.prototype.ditch = function(e) {
   e.stop();
   var doit = confirm("Are you sure you want to delete this album?");
   if(doit) {
      var currentAlbumId = (e.src().parentNode.id).substr(6);
      services.albums.remove(currentAlbumId);
      // Remove the album panel from the display
      switchOff(e.src().parentNode);      
   }
};

/* Toggle the list of existing albums from the display. 
 */
albums.prototype.toggle = function(e) {
   if($('content-pane') != null)
      toggle($('content-pane'), 'appear');
   if($('film-info-pane') != null)
      toggle($('film-info-pane'), 'appear');
   hideElement($('login-pane'));
   // make sure we keep our cursor correctly set
   this.position = 0;
   if(this.visibility == false) {
      this.visibility = true;
      this.forward(e);
   } else {
      this.visibility = false;
      replaceChildNodes($('albums-pane'));
   }
   toggle($('albums-pane'), 'appear');
};

/* Populate the display with the list of albums 
   retrieved from the REST service.
 */
albums.prototype.populate = function(albums) {
   var albumsPane = $('albums-pane');

   // Let's remove any existing children of our 
   // albums list panel and start from a clean 
   // element.
   replaceChildNodes($('albums-pane'));
   
   // Hmm none yet?
   if(albums.length == 0){
      appendChildNodes(albumsPane, 
		       SPAN({'id': 'info-msg', 'class': 'info-msg'}, 'No more album.'));
      appendChildNodes(albumsPane, previous);
      return;
   }

   for(var album in albums) {
      album = albums[album];
      var albumInfoBlock = DIV({'class': 'albums-infos-pane', 'id': 'album-' + album['id']},
			       LABEL({'class': 'infos-label'}, 'Title:'),
			       SPAN({'class': 'infos-content'}, unescape(album['title'])),
			       LABEL({'class': 'infos-label'}, 'Created on:'),
			       SPAN({'class': 'infos-content'}, unescape(album['created'])), 
			       LABEL({'class': 'infos-label'}, 'Updated on:'),
			       SPAN({'class': 'infos-content'}, unescape(album['modified'])), 
			       LABEL({'class': 'infos-label'}, 'Description:'),
			       SPAN({'class': 'infos-content'}, unescape(album['description'])));
      var editAlbumElement = SPAN({'class': 'infos-action'}, 'Edit');
      connect(editAlbumElement, 'onclick', this, 'fetch');
      var deleteAlbumElement = SPAN({'class': 'infos-action'}, 'Delete');
      connect(deleteAlbumElement, 'onclick', this, 'ditch');
      appendChildNodes(albumInfoBlock, editAlbumElement);
      appendChildNodes(albumInfoBlock, deleteAlbumElement);
      connect(albumInfoBlock, 'onclick', this, 'select');
      appendChildNodes(albumsPane, albumInfoBlock);
   }
 
   var previous = SPAN({'id': 'previous-albums', 'class': 'infos-action'}, 'Previous');
   connect(previous, 'onclick', this, 'rewind');
   var next = SPAN({'id': 'next-albums', 'class': 'infos-action'}, 'Next');
   connect(next, 'onclick', this, 'forward');
   var create = SPAN({'class': 'infos-action'}, 'Create');
   connect(create, 'onclick',this, 'blank');
   
   appendChildNodes(albumsPane, previous);
   appendChildNodes(albumsPane, next);
   appendChildNodes(albumsPane, create);
};
   
/* Validate the current form and display
   any error message if a value is missing.
   This is a very very very simple validation 
   which could gain in being more thorough. 
 */
albums.prototype.validate = function(e) {
   var ready = true;
   hideElement($('form-title-error'));
   hideElement($('form-author-error'));
   hideElement($('form-desc-error'));
   
   if($('album-title').value == '') {
      appear($('form-title-error'));
      ready = false;
   }
   
   if($('album-author').value == '') {
      appear($('form-author-error'));
      ready = false;
   }
   
   if($('album-desc').value == '') {
      appear($('form-desc-error'));
      ready = false;
   }
   
   return ready;
};
   
/* Show the messages indicating a success in creation
   or update.
 */
albums.prototype.show_success_message = function() {
   hideElement($('form-title-error'));
   hideElement($('form-author-error'));
   hideElement($('form-desc-error'));
   
   appear($('form-success'));
   fade($('form-submit'));
};
     
/* Show the messages indicating a failure in creation
   or update.
 */
albums.prototype.show_error_message = function() {
   hideElement($('form-title-error'));
   hideElement($('form-author-error'));
   hideElement($('form-desc-error'));
   
   appear($('form-error'));
   fade($('form-submit'));
};

/* Empty form for the creation of a new album.
 */
albums.prototype.blank = function(e) {
   var submitLink = SPAN({'id': 'form-submit', 'class': 'form-link'}, 'Submit');
   var cancelLink = SPAN({'id': 'form-cancel', 'class': 'form-link'}, 'Cancel');
   
   var successMessage = SPAN({'id': 'form-success', 'class': 'form-success'}, 'Album created');
   var errorMessage = SPAN({'id': 'form-error', 'class': 'form-error'}, 'An unexpected error occured');
   var titleErrMsg = SPAN({'id': 'form-title-error', 'class': 'form-error'}, 'You must provide a title');
   var authorErrMsg = SPAN({'id': 'form-author-error', 'class': 'form-error'}, 'You must specify the author name');
   var descErrMsg = SPAN({'id': 'form-desc-error', 'class': 'form-error'}, 'You must provide a description');
   
   var albumForm = DIV({'id': 'pageoverlay'}, 
		       DIV({'id': 'outerbox'},
			   DIV({'id': 'formoverlay'},
			       SPAN({'class': 'form-caption'}, 'Create a new album'), BR(),BR(),
			       FORM({'id': 'create-album',  'name':"albumForm"},
				    titleErrMsg,
				    LABEL({'class': 'form-label'}, 'Title:'),
				    INPUT({'class': 'form-input', 'name': 'title', 
					   'id': 'album-title', 'value': ''}), BR(),
				    authorErrMsg,
				    LABEL({'class': 'form-label'}, 'Author:'),
				    INPUT({'class': 'form-input', 'name': 'author', 
					   'id': 'album-author', 'value': ''}), BR(),
				    descErrMsg,
				    LABEL({'class': 'form-label'}, 'Description:'),
				    TEXTAREA({'class': 'form-textarea', 'name': 'description', 
					      'id': 'album-desc', 'rows': '2', 'value': ''}), BR(), 
				    LABEL({'class': 'form-label'}, 'Content:'),
				    TEXTAREA({'class': 'form-textarea', 'name': 'content', 
					      'id': 'album-content', 'rows': '7', 'value': ''}), BR()),
			       successMessage, errorMessage,
			       DIV({'id': 'form-links'},
				   submitLink, 
				   cancelLink))));
   

   hideElement(titleErrMsg);
   hideElement(authorErrMsg);
   hideElement(descErrMsg);
   hideElement(errorMessage);
   hideElement(successMessage);
   connect(submitLink, 'onclick', this, 'create');
   connect(cancelLink, 'onclick', closeOverlayBox);
   appendChildNodes($('photoblog'), albumForm);
};
