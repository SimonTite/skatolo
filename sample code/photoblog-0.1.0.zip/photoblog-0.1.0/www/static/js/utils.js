
function closeOverlayBox(e) {
   hideElement($('pageoverlay'));
   removeElement($('pageoverlay'));
}

function toggleLoginBox(e) {
   hideElement($('albums-pane'));
   toggle($('login-pane'), 'appear');
}

// 'services' singleton
var services = new service();


function UI() {
};

/* We fake a 'ui' namespace by attaching to a UI singleton
   the other objects we will be using throughout.
 */
UI.prototype.albums = new albums();
UI.prototype.films = new films();
UI.prototype.photos = new photos();
var ui = new UI();

/* The photoblog application uses a plain HTTP authentication
   as specified in RFC 2617. By issuing a simple request to the 
   top level services page handler we do initiate the authentication
   and get the token from the server. This will go through the rest
   of our sesssion until the browser is closed. 
 */
function perform_login() {
   var xmlHttpReq = getXMLHttpRequest();
   xmlHttpReq.open("GET", serviceBaseUri, true, $("username").value, $("password").value);
   var d = sendXMLHttpRequest(xmlHttpReq);
   d.addCallback(function (data) {
      hideElement($('login-pane'));
   });
   d.addErrback(function (data){
   });
};

/* A bunch of initialisation to be done when the page is loaded.
 */
function initialize(e) {
   hideElement($('albums-pane'));
   hideElement($('login-pane'));
   connect($('manage'), 'onclick', ui.albums, 'toggle');
   connect('login', 'onclick', toggleLoginBox);
   connect($('login-submit'), 'onclick', perform_login);
}

connect(window, 'onload', initialize);
