/**************************************************
 * Javascript module that handles the photo entity
 *************************************************/

/* Let's inform Javascript we will be using the
   photos function as a constructor */
photos.prototype.constructor = photos;


/**************************************************
 * Photograph class definition
 *************************************************/
function photos() {
   this.current_photo_id = null;
};

var upload_window = null;

/* Sadly uploadng a file with Ajax is not possible to the security limitations
   of Javascript. Therefore here we open a popup window with a true HTML form
   that will upload the file.
 */
photos.prototype.open_photo_upload_window = function() {
   window.open(photoUploadBaseUri + this.current_photo_id , "popup_id", "resizable,width=350,height=20");
   this.current_photo_id = null;
}

photos.prototype.show_upload_link = function(photo) {
   this.current_photo_id = photo['id'];
   connect($('form-upload'), 'onclick', this, 'open_photo_upload_window');
   appear($('form-upload'));
};

photos.prototype.create = function(e) {
   if(this.validate()) {
      var data = {'film_id': $('film-id').value, 'name': escape($('photo-name').value),
		  'legend': escape($('photo-legend').value)};
      
      services.photos.create(data);
   }
};

photos.prototype.fetch = function(e) {
   e.stop();   
   var photo_id = getNodeAttribute(e.src(), 'value');
   services.photos.fetch(photo_id);
};

photos.prototype.update = function(e) {
   if(this.validate()) {
      var legend = $('photo-legend').value;
      if(legend == '') {
	 legend = 'N/A';
      }
      var data = {'name': escape($('photo-name').value), 'legend': escape($('legend').value)};
      services.photos.update($('photo-id').value, data);
   }
};

/* Send the message to the REST service that the current photograph
   can be deleted from the system.
 */
photos.prototype.ditch = function(e) {
   e.stop();
   var doit = confirm("Are you sure you want to delete this photograph?");
   if(doit) {
      services.photos.remove($('photo-id').value);
      hideElement($('form-upload'));
      hideElement($('form-delete'));
      hideElement($('form-submit'));
   }
};

photos.prototype.edit = function(photo) {
   var uploadLink = SPAN({'id': 'form-upload', 'class': 'form-link'}, 'Upload');
   var deleteLink = SPAN({'id': 'form-delete', 'class': 'form-link'}, 'Delete');
   var submitLink = SPAN({'id': 'form-submit', 'class': 'form-link'}, 'Submit');
   var cancelLink = SPAN({'id': 'form-cancel', 'class': 'form-link'}, 'Cancel');

   var successMessage = SPAN({'id': 'form-success', 'class': 'form-success'}, 'Photo updated');
   var errorMessage = SPAN({'id': 'form-error', 'class': 'form-error'}, 'An unexpected error occured');
   var nameErrMsg = SPAN({'id': 'form-name-error', 'class': 'form-error'}, 'You must provide a name');
   
   replaceChildNodes($('formoverlay'));
   var photoForm = FORM({'id': 'update-photo',  'name': "photoForm"},
		       INPUT({'name': 'id', 'id': 'photo-id', 
			      'type': 'hidden', 'value': photo['id']}),
		       nameErrMsg,
		       LABEL({'class': 'form-label'}, 'Name:'),
		       INPUT({'class': 'form-input', 'name': 'name', 
			      'id': 'photo-name', 'value': unescape(photo['name'])}), BR(),
		       LABEL({'class': 'form-label'}, 'Legend:'),
		       TEXTAREA({'class': 'form-textarea', 'name': 'legend', 
				 'id': 'photo-legend', 'rows': '2'}, unescape(photo['legend'])), BR(), 
		       successMessage, errorMessage,
		       DIV({'id': 'form-links'},
			   uploadLink,
			   deleteLink,
			   submitLink, 
			   cancelLink));

   hideElement(nameErrMsg);
   hideElement(errorMessage);
   hideElement(successMessage);
   connect(deleteLink, 'onclick', this, 'ditch');
   connect(submitLink, 'onclick', this, 'update');
   connect(cancelLink, 'onclick', closeOverlayBox);
   this.current_photo_id = photo['id'];
   connect(uploadLink, 'onclick', this, 'open_photo_upload_window');
   appendChildNodes($('formoverlay'), SPAN({'class': 'form-caption'}, 'Edit a photograph'));
   appendChildNodes($('formoverlay'), BR());
   appendChildNodes($('formoverlay'), BR());
   appendChildNodes($('formoverlay'), photoForm);
};

photos.prototype.display = function(photos) {
   var create = SPAN({'class': 'infos-action'}, 'Create');
   connect(create, 'onclick', this, 'blank');
   
   var film_id = $('film-id').value;
   replaceChildNodes($('formoverlay'));
   appendChildNodes($('formoverlay'), INPUT({'name': 'id', 'id': 'film-id', 
					     'type': 'hidden', 'value': film_id}));
   if(photos.length == 0){
      appendChildNodes($('formoverlay'), SPAN({'class': 'form-caption'}, 'Create a new photograph'));
      appendChildNodes($('formoverlay'), BR());
      appendChildNodes($('formoverlay'), BR());
      appendChildNodes($('formoverlay'), create);
      return;
   }

   var photosSelect = SELECT();

   for(var photo in photos) {
      photo = photos[photo];
      var photoOption = OPTION({'value': photo['id']}, photo['name']);
      connect(photoOption, 'onclick', this, 'fetch');
      appendChildNodes(photosSelect, photoOption);
   }
     
   appendChildNodes($('formoverlay'), SPAN({'class': 'form-caption'}, 'Edit or create a photograph'));
   appendChildNodes($('formoverlay'), BR());
   appendChildNodes($('formoverlay'), BR());
   appendChildNodes($('formoverlay'), SPAN({}, 'Edit: '));
   appendChildNodes($('formoverlay'), photosSelect);
   appendChildNodes($('formoverlay'), BR());
   appendChildNodes($('formoverlay'), create);
};

 
photos.prototype.validate = function(e) {
   var ready = true;
   hideElement($('form-name-error'));
   
   if($('photo-name').value == '') {
      appear($('form-name-error'));
      ready = false;
   }
   
   return ready;
};
 
photos.prototype.show_success_message = function() {
   hideElement($('form-name-error'));

   appear($('form-success'));
   fade($('form-submit'));
};
   
photos.prototype.show_error_message = function() {
   hideElement($('form-name-error'));
   
   appear($('form-error'));
   fade($('form-submit'));
};
   
photos.prototype.blank = function(e) {
   var uploadLink = SPAN({'id': 'form-upload', 'class': 'form-link'}, 'Upload');
   var submitLink = SPAN({'id': 'form-submit', 'class': 'form-link'}, 'Submit');
   var cancelLink = SPAN({'id': 'form-cancel', 'class': 'form-link'}, 'Cancel');
   
   var successMessage = SPAN({'id': 'form-success', 'class': 'form-success'}, 'Photography created');
   var errorMessage = SPAN({'id': 'form-error', 'class': 'form-error'}, 'An unexpected error occured');
   var nameErrMsg = SPAN({'id': 'form-name-error', 'class': 'form-error'}, 'You must provide a name');

   var film_id = $('film-id').value;
   replaceChildNodes($('formoverlay'));
   var photographyLink = A({'id': 'upload'}, 'Upload a photography');

   var filmForm = FORM({'id': 'create-photo',  'name': "photoForm"},
		       INPUT({'name': 'id', 'id': 'film-id', 
			      'type': 'hidden', 'value': film_id}),
		       nameErrMsg,
		       LABEL({'class': 'form-label'}, 'Name:'),
		       INPUT({'class': 'form-input', 'name': 'name', 
			      'id': 'photo-name', 'value': ''}), BR(),
		       LABEL({'class': 'form-label'}, 'Legend:'),
		       TEXTAREA({'class': 'form-textarea', 'name': 'legend', 
				 'id': 'photo-legend', 'rows': '2', 'value': ''}, 'N/A'), BR(), 
		       successMessage, errorMessage,
		       DIV({'id': 'form-links'},
			   uploadLink,
			   submitLink, 
			   cancelLink));
   
   hideElement(nameErrMsg);
   hideElement(errorMessage);
   hideElement(successMessage);
   hideElement(uploadLink);
   connect(submitLink, 'onclick', this, 'create');
   connect(cancelLink, 'onclick', closeOverlayBox);
   appendChildNodes($('formoverlay'), SPAN({'class': 'form-caption'}, 'Create a new photograph'));
   appendChildNodes($('formoverlay'), BR());
   appendChildNodes($('formoverlay'), BR());
   appendChildNodes($('formoverlay'), filmForm);
};
