# -*- coding: utf-8 -*-

import datetime

from bridge import Element as E
from bridge.common import ATOM10_PREFIX, ATOM10_NS

from uuid import uuid1
import simplejson
from dejavu import Unit, UnitProperty

from lib.storage import arena
from lib import conf, lesser_comparer, greater_comparer
from photo import Photo
import album

class Film(Unit):
    uuid = UnitProperty(unicode)
    title = UnitProperty(unicode)
    description = UnitProperty(unicode)
    created = UnitProperty(datetime.datetime)
    modified = UnitProperty(datetime.datetime)
    album_id = UnitProperty(int, index=True)

    def on_forget(self):
        """Called by dejavu when removing a unit from a storage. 
        Allows us to implement delete cascade"""
        for photo in self.Photo():
            photo.forget()

    def photos(self):
        """Returns an iterator over photos associated to this film"""
        return self.Photo()
    photos = property(photos)

    def children(self):
        return self.photos
    children = property(children)
    
    def album(self):
        """Returns the album owning this film"""
        return self.Album()
    album = property(album)

    def author(self):
        """Returns the author name of the album
        owning the film"""
        return self.album.author
    author = property(author)

    def container(self):
        """Returns the container holding this film"""
        return self.Album()
    container = property(container)

    def count_visible(self):
        """We count a photograph as publicly visible
        when its filename is set"""
        count = 0
        for photo in self.photos:
            if photo.filename:
                count = count + 1
        return count

    def photos_id_sorted_by_created_date(self, comparer):
        """Sorts photograph owned by this film following
        their creation date.
        """
        sandbox = arena.new_sandbox()
        film_ids = []
        for film in self.album.films:
            film_ids.append(film.ID)
        v = list(sandbox.view(Photo, ('ID', 'created'), lambda a: a.film_id in film_ids))
        v.sort(cmp=comparer)

        return v

    def previous_and_next(self, current):
        """Returns the previous and next photograph in regards to the 'current'
        provided in the parameters. The result is returned as a tuple of Photo
        instances. If there is no previous and/or next then None is returned in the
        tuple. The search is global to the album not to the film.
        """
        sandbox = arena.new_sandbox()
        # We want to know the previous and next photo in the context of the album
        # not the film itself.
        film_ids = []
        for film in self.album.films:
            film_ids.append(film.ID)
        previous = list(sandbox.view(Photo, ('ID', 'created'), lambda a: a.created < current.created \
                                     and a.film_id in film_ids))
        next = list(sandbox.view(Photo, ('ID', 'created'), lambda a: a.created > current.created \
                                 and a.film_id in film_ids))

        previous.sort(cmp=lesser_comparer)
        next.sort(cmp=greater_comparer)
        
        if previous:
            previous = sandbox.recall(Photo, lambda x: x.ID == previous[0][0])
            if previous:
                previous = previous[0]
        else:
            previous = None
            
        if next:
            next = sandbox.recall(Photo, lambda x: x.ID == next[0][0])
            if next:
                next = next[0]
        else:
            next = None

        return previous, next
    
    def get_first_photo(self):
        """Returns the first photograph of the film"""
        v = self.photos_id_sorted_by_created_date(comparer=greater_comparer)
        if v:
            sandbox = arena.new_sandbox()
            return sandbox.recall(Photo, lambda x: x.ID == v[0][0])[0]
    first_photo = property(get_first_photo)
    
    def get_last_photo(self):
        """Returns the last photograph of the film"""
        v = self.photos_id_sorted_by_created_date(comparer=lesser_comparer)
        print v
        if v:
            sandbox = arena.new_sandbox()
            return sandbox.recall(Photo, lambda x: x.ID == v[0][0])[0]
    last_photo = property(get_last_photo)

    def to_dict(self):
        """Serializes the film into a dictionary"""
        return {'id': self.ID,
                'album_id': self.album_id,
                'uuid': self.uuid,
                'title': self.title,
                'description': self.description,
                'created': self.created.isoformat() + 'Z',
                'modified': self.modified.isoformat() + 'Z'}
    
    def to_json(self):
        """JSONify a film properties"""
        return simplejson.dumps(self.to_dict())
        
    def to_atom_entry(self):
        """Returns an Atom 1.0 entry as per RFC 4287"""

        entry = E(u'entry')
        E(u'id', content=u'urn:uuid:%s' % self.uuid, parent=entry)
        E(u'title', content=self.title, parent=entry)
        author = E(u'author', parent=entry)
        E(u'name', content=self.album.author, parent=author)
        E(u'published', content=unicode(self.created.isoformat() + 'Z'), parent=entry)
        E(u'updated', content=unicode(self.modified.isoformat() + 'Z'), parent=entry)
        E(u'rights', content=unicode(conf.app.copyright), attributes={u'type': u'text'}, parent=entry)
        E(u'summary', content=self.description, attributes={u'type': u'html'}, parent=entry)
        E(u'link', attributes={u'href': unicode('%s%s%d' % (conf.app.base_url, conf.film.base_uri, self.ID)),
                               u'rel': u'self', u'type': u'application/atom+xml;type=entry'}, parent=entry)
        E(u'link', attributes={u'href': unicode('%s%s%d' % (conf.app.base_url, conf.film.base_uri, self.ID)),
                               u'rel': u'alternate', u'type': u'text/html'}, parent=entry)
        E(u'link', attributes={u'href': unicode('%s%s%d' % (conf.app.base_url, conf.film.feed_uri, self.ID)),
                               u'rel': u'alternate', u'type': u'application/atom+xml;type=feed'}, parent=entry)
        entry.update_prefix(ATOM10_PREFIX, None, ATOM10_NS, update_attributes=False)
        
        return entry

    def get_all(cls):
        """Returns all films in the storage manager"""
        sandbox = arena.new_sandbox()
        return sandbox.recall(Film)
    films = classmethod(get_all)

    def fetch(cls, id):
        """Returns one film per its ID"""
        sandbox = arena.new_sandbox()
        return sandbox.unit(Film, ID=int(id))
    fetch = classmethod(fetch)
    
    def fetch_by_uuid(cls, uuid):
        """Fetch one film by uuid"""
        sandbox = arena.new_sandbox()
        return sandbox.unit(Film, uuid=uuid)
    fetch_by_uuid = classmethod(fetch_by_uuid)
    
    def create(self, album, title, description, uuid=None):
        """Creates a film and attaches it to an album"""
        sandbox = arena.new_sandbox()

        if uuid is None:
            uuid = unicode(uuid1())
        self.uuid = uuid
        self.title = title
        self.description = description
        self.created = datetime.datetime.now().replace(microsecond=0)
        self.modified = self.created
        self.album_id = album.ID
        
        sandbox.memorize(self)
        sandbox.flush_all()
    
    def update(self, title, description):
        """Updates a film properties"""
        self.title = title
        self.description = description
        self.modified = datetime.datetime.now().replace(microsecond=0)
        self.sandbox.flush_all()
            
    def delete(self):
        """Remove a film from the storage"""
        self.sandbox.forget(self)

# Association between the film and its photographs
Film.one_to_many('ID', Photo, 'film_id')
