# -*- coding: utf-8 -*-

from dejavu import Unit, UnitProperty

from lib import lesser_comparer, greater_comparer
from lib.storage import arena
from album import Album

class Photoblog(Unit):
    name = UnitProperty(unicode)
    title = UnitProperty(unicode)

    def albums(self):
        """Returns all the albums of the photoblog"""
        return self.Album()
    albums = property(albums)

    def on_forget(self):
        """Called by dejavu when removing a unit from a storage. 
        Allows us to implement delete cascade"""
        for album in self.albums:
            album.forget()

    def get_first_album(self):
        """Returns the first album created in this photoblog"""
        sandbox = arena.new_sandbox()
        v = list(sandbox.view(Album, ('ID', 'created'), lambda a: a.blog_id == self.ID))
        v.sort(cmp=greater_comparer)
        if v:
            return sandbox.recall(Album, lambda x: x.ID == v[0][0])[0]
    first_album = property(get_first_album)
    
    def get_last_album(self):
        """Returns the last album created in this photoblog"""
        sandbox = arena.new_sandbox()
        v = list(sandbox.view(Album, ('ID', 'created'), lambda a: a.blog_id == self.ID))
        v.sort(cmp=lesser_comparer)
        if v:
            return sandbox.recall(Album, lambda x: x.ID == v[0][0])[0]
    last_album = property(get_last_album)
    
    def get_previous_album(self, album):
        """Returns the previous album of 'album' in this blog"""
        sandbox = arena.new_sandbox()
        v = list(sandbox.view(Album, ('ID', 'created'), lambda a: a.created < album.created \
                              and a.blog_id == self.ID))
        v.sort(cmp=lesser_comparer)
        if v:
            return sandbox.recall(Album, lambda x: x.ID == v[0][0])[0]
    
    def create(self, name, title):
        """Instanciates one Photoblog and
        persists the changes into the storage"""
        sandbox = arena.new_sandbox()

        self.name = name
        self.title = title
        
        sandbox.memorize(self)
        sandbox.flush_all()
    
    def update(self, title):
        """Update the attributes of a photoblog instance
        and then persist the modification into the database"""
        self.title = title
        self.sandbox.flush_all()
            
    def delete(self):
        """Delete a photoblog from the storage"""
        self.sandbox.forget(self)
    
    def current(cls):
        """Returns the current blog or None if there is none"""
        sandbox = arena.new_sandbox()
        return sandbox.unit(Photoblog)
    current = classmethod(current)
    
    def fetch(cls, id):
        """Returns a photoblog by its internal id"""
        sandbox = arena.new_sandbox()
        return sandbox.unit(Photoblog, ID=int(id))
    fetch = classmethod(fetch)
    
    def find_by_name(cls, name):
        """Returns a photoblog by its name"""
        sandbox = arena.new_sandbox()
        return sandbox.unit(Photoblog, name=name)
    find_by_name = classmethod(find_by_name)

# Association of the photoblog with its albums
Photoblog.one_to_many('ID', Album, 'blog_id')
