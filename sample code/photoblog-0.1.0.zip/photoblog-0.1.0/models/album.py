# -*- coding: utf-8 -*-

# The album module contains the definition of
# the class mapping accross the storage backend
# and the application layer.


# Python stdlib import
import datetime

# Common external packages imports
from uuid import uuid1
import simplejson
from dejavu import Unit, UnitProperty

from bridge import Element as E
from bridge import Attribute
from bridge.common import ATOM10_NS, ATOM10_PREFIX
from bridge.filter import atom

# Photoblog imports
from lib.storage import arena
from lib import conf, lesser_comparer, greater_comparer
from film import Film

class Album(Unit):
    uuid = UnitProperty(unicode)
    title = UnitProperty(unicode)
    author = UnitProperty(unicode)
    description = UnitProperty(unicode)
    content = UnitProperty(unicode, hints={u'bytes': 0})
    created = UnitProperty(datetime.datetime)
    modified = UnitProperty(datetime.datetime)
    blog_id = UnitProperty(int, index=True)

    def on_forget(self):
        """Called by dejavu when removing a unit from a storage. 
        Allows us to implement delete cascade"""
        for film in self.Film():
            film.forget()

    def films(self):
        """Returns all the attached films of this album"""
        return self.Film()
    films = property(films)

    def children(self):
        """Returns all the children elements of an album
           Since we only have films as children, it
           only returns those."""
        return self.films
    children = property(children)

    def blog(self):
        """Returns the photoblog owning this album"""
        return self.Photoblog()
    photoblog = property(blog)
    
    def container(self):
        """Returns the object owning this album"""
        return self.Photoblog()
    container = property(container)

    def to_dict(self):
        """Return an album as a Python dictionary"""
        return {'id': self.ID,
                'uuid': self.uuid,
                'title': self.title,
                'author': self.author,
                'description': self.description,
                'content': self.content,
                'created': self.created.strftime("%d %b. %Y, %H:%M"),
                'modified': self.modified.strftime("%d %b. %Y, %H:%M")}
 
    def to_json(self):
        """JSONify an album properties"""
        return simplejson.dumps(self.to_dict())
              
    def to_atom_entry(self):
        """Returns an Atom 1.0 entry as per RFC 4287"""

        entry = E(u'entry')
        E(u'id', content=u'urn:uuid:%s' % self.uuid, parent=entry)
        E(u'title', content=self.title, parent=entry)
        author = E(u'author', parent=entry)
        E(u'name', content=self.author, parent=author)
        E(u'published', content=unicode(self.created.isoformat() + 'Z'), parent=entry)
        E(u'updated', content=unicode(self.modified.isoformat() + 'Z'), parent=entry)
        attr = {u'href': unicode('%s%s%d' % (conf.app.base_url, conf.album.feed_uri, self.ID)),
                u'rel': u'alternate', u'type': u'application/atom+xml;type=feed'}
        E(u'link', attributes=attr, parent=entry)
        attr = {u'href': unicode('%s%s%d' % (conf.app.base_url, conf.album.base_uri, self.ID)),
                u'rel': u'alternate', u'type': u'text/html'}
        E(u'link', attributes=attr, parent=entry)
        attr = {u'href': unicode('%s%s%d' % (conf.app.base_url, conf.album.base_uri, self.ID)),
                u'rel': u'self', u'type': u'application/atom+xml;type=entry'}
        E(u'link', attributes=attr, parent=entry)
        attr = {u'type': u'text'}
        E(u'content', content=unicode(conf.app.copyright), attributes=attr, parent=entry)
        attr = {u'type': u'html'}
        E(u'summary', content=self.description, attributes=attr, parent=entry)
        attr = {u'type': u'xhtml'}
        E(u'content', content=self.content, attributes=attr, parent=entry)

        entry.update_prefix(ATOM10_PREFIX, None, ATOM10_NS, update_attributes=False)
        
        return entry

    def get_all(cls):
        """Returns all the existing albums""" 
        sandbox = arena.new_sandbox()
        return sandbox.recall(Album)
    albums = classmethod(get_all)

    def get_first_film(self):
        """Returns the first film by its creation date
        owned by this album."""

        sandbox = arena.new_sandbox()
        
        # To get a sorted list of films for this album
        # we use the concept of View that dejavu provides.
        # We indicate which unit type we are looking after
        # then which unit properties of that unit we are
        # interested in.
        # We make a list of the returned view.
        
        v = list(sandbox.view(Film, ('ID', 'created'), lambda a: a.album_id == self.ID))
        if v:
            # The list is constituted of tuples were each
            # item of the tuple is the value of the unit
            # following the properties order provided above
            # when creating the view, for example:
            # [(datetime, 3), (datetime, 1)]
            # We now sort this list based on the creation date.
            v.sort(cmp=greater_comparer)
            
            # We can now retrieve the list of films which belong
            # to this album and we return the first one
            return sandbox.recall(Film, lambda x: x.ID == v[0][0])[0]
    first_film = property(get_first_film)
       
    def fetch_range(cls, start, end):
        """Fetch a range of albums

        For example:

        >>> Album.fetch_range(6, 10)

        Will return all albums that have an ID within that range
        or an empty list.
        """
        sandbox = arena.new_sandbox()
        v = list(sandbox.view(Album, ['created', 'ID']))
        v.sort()
        size = len(v)
        if end > size and start >= size:
            return None
        elif end > size and start < size:
            end = size
        # The targets list is constitued of album IDs
        # within the requested range
        targets = [row[1] for row in v[start:end]]
        return sandbox.recall(Album, lambda x: x.ID in targets)
    fetch_range = classmethod(fetch_range)
    
    def fetch(cls, id):
        """Fetch one album by id"""
        try:
            id = int(id)
        except ValueError:
            return None
        sandbox = arena.new_sandbox()
        return sandbox.unit(Album, ID=id)
    fetch = classmethod(fetch)
    
    def fetch_by_uuid(cls, uuid):
        """Fetch one album by id"""
        sandbox = arena.new_sandbox()
        return sandbox.unit(Album, uuid=uuid)
    fetch_by_uuid = classmethod(fetch_by_uuid)
    
    def create(self, photoblog, title, author, description, content, uuid=None):
        """Instanciates one Album,
        adds it to the passed photoblog and
        persists the changes into the storage"""
        sandbox = arena.new_sandbox()

        if not uuid:
            uuid = uuid1()
        self.uuid = uuid 
        self.title = title
        self.author = author
        self.description = description
        self.content = content
        self.created = datetime.datetime.now().replace(microsecond=0)
        self.modified = self.created
        self.blog_id = photoblog.ID
        sandbox.memorize(self)
        photoblog.add(self)
        
        sandbox.flush_all()
    
    def update(self, title, author, description, content):
        """Updates the attributes of an album and
        persists the changes into the storage"""
        self.title = title
        self.author = author
        self.description = description
        self.content = content
        self.modified = datetime.datetime.now().replace(microsecond=0)
        self.sandbox.flush_all()
            
    def delete(self):
        """Delete an album from the storage"""
        self.sandbox.forget(self)

# Define the relationship between Album and Film
Album.one_to_many('ID', Film, 'album_id')
