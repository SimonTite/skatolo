# -*- coding: utf-8 -*-

import datetime

from bridge import Element as E
from bridge.common import ATOM10_PREFIX, ATOM10_NS

from dejavu import Unit, UnitProperty, logic
from lib.storage import arena
import simplejson
from uuid import uuid1
from lib import conf

class Photo(Unit):
    uuid = UnitProperty(unicode)
    name = UnitProperty(unicode)
    legend = UnitProperty(unicode)
    filename = UnitProperty(unicode)
    filesize = UnitProperty(int)
    mediatype = UnitProperty(unicode)
    width = UnitProperty(int)
    height = UnitProperty(int)
    created = UnitProperty(datetime.datetime)
    modified = UnitProperty(datetime.datetime)
    film_id = UnitProperty(int, index=True)
    
    def film(self):
        """Returns the film owning this photo"""
        return self.Film()
    film = property(film)

    def children(self):
        """A photograph has no children but we
        define the method anyway to simplify the
        prcessing later on"""
        pass
    children = property(children)

    def album(self):
        """Returns the album owning the film owning the photo"""
        return self.film.album
    album = property(album)
    
    def author(self):
        """Returns the author of the album owning this photo"""
        return self.film.author
    author = property(author)

    def container(self):
        """Returns the container entity owning this photo"""
        return self.Film()
    container = property(container)

    def title(self):
        """In some parts of the application we prefer using
        'title' rather than name. Returns the name of the photo"""
        return self.name
    title = property(title)

    def to_dict(self):
        """Serializes the photo as a dictionary"""
        return {'id': self.ID,
                'uuid': self.uuid,
                'film_id': self.film_id,
                'name': self.name,
                'legend': self.legend,
                'width': self.width,
                'height': self.height,
                'mediatype': self.mediatype,
                'created': self.created.isoformat() + 'Z',
                'modified': self.modified.isoformat() + 'Z'}
    
    def to_json(self):
        """JSONify a photo properties"""
        return simplejson.dumps(self.to_dict())
                           
    def to_atom_entry(self):
        """Returns an Atom 1.0 entry as per RFC 4287"""
        
        entry = E(u'entry')
        E(u'id', content=u'urn:uuid:%s' % self.uuid, parent=entry)
        E(u'title', content=self.title, parent=entry)
        author = E(u'author', parent=entry)
        E(u'name', content=self.author, parent=author)
        E(u'published', content=unicode(self.created.isoformat() + 'Z'), parent=entry)
        E(u'updated', content=unicode(self.modified.isoformat() + 'Z'), parent=entry)
        E(u'rights', content=unicode(conf.app.copyright), attributes={u'type': u'text'}, parent=entry)
        E(u'summary', content=self.legend, attributes={u'type': u'html'}, parent=entry)
        E(u'link', attributes={u'href': unicode('%s%s%d' % (conf.app.base_url, conf.photograph.base_uri, self.ID)),
                               u'rel': u'self', u'type': u'application/atom+xml;type=entry'}, parent=entry)
        E(u'link', attributes={u'href': unicode('%s%s%d' % (conf.app.base_url, conf.photograph.base_uri, self.ID)),
                               u'rel': u'alternate', u'type': u'text/html'}, parent=entry)
        E(u'link', attributes={u'href': unicode('%s%s%d' % (conf.app.base_url, conf.photograph.feed_uri, self.ID)),
                               u'rel': u'alternate', u'type': u'application/atom+xml;type=feed'}, parent=entry)
        if self.filename:
            E(u'content', attributes={u'src': unicode('%s/media/%s' % (conf.app.base_url, self.filename)),
                                      u'type': self.mediatype, u'length': unicode(self.filesize)}, parent=entry)
        entry.update_prefix(ATOM10_PREFIX, None, ATOM10_NS, update_attributes=False)
        
        return entry
    
    def get_all(cls):
        """Returns all photos in the storage manager"""
        sandbox = arena.new_sandbox()
        return sandbox.recall(Photo)
    photos = classmethod(get_all)

    def fetch(cls, id):
        """Returns a photo per its ID"""
        sandbox = arena.new_sandbox()
        return sandbox.unit(Photo, ID=int(id))
    fetch = classmethod(fetch)
    
    def fetch_by_uuid(cls, uuid):
        """Fetch one photograph by uuid"""
        sandbox = arena.new_sandbox()
        return sandbox.unit(Photo, uuid=uuid)
    fetch_by_uuid = classmethod(fetch_by_uuid)
    
    def create(self, film, name, legend, filename=None, mediatype=None,
               width=None, height=None, uuid=None):
        """Creates a Photo object and fill some of its properties"""
        if not uuid:
            uuid = unicode(uuid1())
        self.uuid = uuid
        self.name = name
        self.legend = legend
        self.filename = filename
        self.mediatype = mediatype
        self.width = width
        self.height = height
        self.created = datetime.datetime.now().replace(microsecond=0)
        self.modified = self.created
        self.film_id = film.ID
        
        sandbox = arena.new_sandbox()
        sandbox.memorize(self)
        sandbox.flush_all()

    def update(self, name, legend, filename=None, mediatype=None, width=None, height=None, filesize=None):
        """Update a Photo object properties"""
        self.name = name
        self.legend = legend
        self.filename = filename
        self.mediatype = mediatype
        self.width = width
        self.height = height
        self.filesize = filesize
        self.modified = datetime.datetime.now().replace(microsecond=0)
        self.sandbox.flush_all()

    def delete(self):
        """Remove a photography from the storage"""
        self.sandbox.forget(self)
