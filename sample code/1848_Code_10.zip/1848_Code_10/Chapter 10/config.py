
import ConfigParser

class Config(object):
    def from_ini(self, filepath, encoding='ISO-8859-1'):
        config = ConfigParser.ConfigParser()
        config.readfp(file(filepath, 'rb'))

        for section in config.sections():
            section_prop = Config()
            section_prop.keys = []
            setattr(self, section, section_prop)
            for option in config.options(section):
                section_prop.keys.append(option)
                value = config.get(section, option).decode(encoding)
                setattr(section_prop, option, value)

if __name__ == '__main__':
    conf = Config()
    conf.from_ini('some.conf')
    print dir(conf)
    print conf.app.copyright
    print conf.storage.host
