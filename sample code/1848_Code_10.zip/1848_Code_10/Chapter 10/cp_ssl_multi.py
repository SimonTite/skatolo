import cherrypy
from cherrypy import _cpwsgi

import os, os.path
localDir = os.path.abspath(os.path.dirname(__file__))
CA = os.path.join(localDir, 'server.crt')
KEY = os.path.join(localDir, 'server.key')

class Root:
    @cherrypy.expose
    def index(self):
        return "Hello there %s " % cherrypy.request.remote.ip
  
if __name__ == '__main__':
    cherrypy.tree.mount(Root())
    cherrypy.config.update({'environment': 'production',
                            'log.screen': True,})
    s1 = _cpwsgi.CPWSGIServer()
    s2 = _cpwsgi.CPWSGIServer()
    s2.ssl_certificate = CA
    s2.ssl_private_key = KEY
    s2.bind_addr = ('localhost', 8443)
    cherrypy.server.httpservers = {s1: ('localhost', 8080),
                                   s2: ('localhost', 8443)}
    cherrypy.server.start()
    cherrypy.engine.start()
