import kid
params = {'title': 'Some songs', 'infos': [{'artist': 'Jeff Buckley', 'album': 'Grace', 'song': 'Mojo Pin'}, {'artist': "Bonnie 'Prince' Billy", 'album': 'Master and everyone', 'song': 'The way'}]}

t = kid.Template('index.kid', **params)
print t.serialize(output='html')
