import kid
params = {'title': 'Hello world', 'message': 'Not much to say.'}
t = kid.Template('simple_kid.kid', **params)
print t.serialize(output='html')
