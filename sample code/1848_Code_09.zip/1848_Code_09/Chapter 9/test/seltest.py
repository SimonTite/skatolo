from selenium.selenium import selenium
import unittest, time, re

class TestHTML(unittest.TestCase):
    def setUp(self):
        self.verificationErrors = []
        self.selenium = selenium("localhost", 4444, "*firefox", "http://localhost:8080")
        self.selenium.start()
    
    def test_seltest(self):
        sel = self.selenium
        sel.open("/")
        sel.click("link=Get report")
        sel.wait_for_page_to_load("5000")
        try: self.failUnless(sel.is_text_present("HTML"))
        except AssertionError, e: self.verificationErrors.append(str(e))
    
    def tearDown(self):
        self.selenium.stop()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
