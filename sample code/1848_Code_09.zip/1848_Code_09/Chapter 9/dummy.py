class Dummy:
    def __init__(self, start=0, left_boundary=-10, right_boundary=10,
                 allow_positive=True, allow_negative=False):
        """
        >>> dummy = Dummy(start=27)
        Traceback (most recent call last):
          ...
            raise ValueError, "Start point must belong to the boundaries"
        ValueError: Start point must belong to the boundaries
        >>> dummy = Dummy()
        >>> dummy.backward()
        Traceback (most recent call last):
          ...
            raise ValueError, "Negative values are not allowed"
        ValueError: Negative values are not allowed

        """
        self.current = start
        self.left_boundary = left_boundary
        self.right_boundary = right_boundary
        self.allow_positive = allow_positive
        self.allow_negative = allow_negative

        if (start > right_boundary) or (start < left_boundary):
            raise ValueError, "Start point must belong to the boundaries"

    def forward(self):
        """
        >>> dummy = Dummy(right_boundary=3)
        >>> dummy.forward()
        1
        >>> dummy.forward()
        2
        >>> dummy.forward()
        3
        >>> dummy.forward()
        Traceback (most recent call last):
          ...
            raise ValueError, "Right boundary reached"
        ValueError: Right boundary reached

        """
        next = self.current + 1
        if (next > 0) and (not self.allow_positive):
            raise ValueError, "Positive values are not allowed"
        if next > self.right_boundary:
            raise ValueError, "Right boundary reached"
        self.current = next
        return self.current

    def backward(self):
        """
        >>> dummy = Dummy(left_boundary=-3, allow_negative=True)
        >>> dummy.forward()
        1
        >>> dummy.backward()
        0
        >>> dummy.backward()
        -1
        >>> dummy.backward()
        -2
        >>> dummy.backward()
        -3
        >>> dummy.backward()
        Traceback (most recent call last):
          ...
            raise ValueError, "Left boundary reached"
        ValueError: Left boundary reached

        """
        prev = self.current - 1
        if (prev < 0) and (not self.allow_negative):
            raise ValueError, "Negative values are not allowed"
        if prev < self.left_boundary:
            raise ValueError, "Left boundary reached"
        self.current = prev
        return self.current

    def __str__(self):
        return str(self.current)
    
    def __repr__(self):
        return "Dummy object at %s" % hex(id(self))

if __name__ == '__main__':
    import doctest
    doctest.testmod()
