import datetime
import os.path

import cherrypy
import simplejson

_header = """<html>
<head><title>Selenium test</title></head>
<script type="application/javascript" src="MochiKit/MochiKit.js"> </script>
<script type="application/javascript" src="MochiKit/New.js"> </script>
<script type="application/javascript">
var fetchReport = function() {
    var xmlHttpReq = getXMLHttpRequest();
    xmlHttpReq.open("GET", "/fetch_report", true); 
    xmlHttpReq.setRequestHeader('Connection', 'close');
    xmlHttpReq.setRequestHeader('Accept', 'application/json');
    var d = sendXMLHttpRequest(xmlHttpReq);
    d.addCallback(function (data) {
       var reportData = evalJSONRequest(data);
       swapDOM($('reportName'), SPAN({'id': 'reportName'}, reportData['name']));
       swapDOM($('reportAuthor'), SPAN({'id': 'reportAuthor'}, reportData['author']));
       swapDOM($('reportUpdated'), SPAN({'id': 'reportUpdated'}, reportData['updated']));
    });
}
</script>
<body>
<div>
<a href="javascript:void(0);" onclick="fetchReport();">Get report via Ajax</a>
<br />
<a href="report">Get report</a>
</div>
<br />
"""

_footer = """
</body>
</html>
"""

class Dummy:
    @cherrypy.expose
    def index(self):
        return """%s
<div id="report">
  <span>Name:</span>
  <span id="reportName"></span>
  <br />
  <span>Author:</span>
  <span id="reportAuthor"></span>
  <br />
  <span>Updated:</span>
  <span id="reportUpdated"></span>
</div>%s""" % (_header, _footer)

  
    @cherrypy.expose
    def report(self):
        now = datetime.datetime.now().strftime("%d %b. %Y, %H:%M:%S")
        return """%s
<div id="report">
  <span>Name:</span>
  <span id="reportName">Music report (HTML)</span>
  <br />
  <span>Author:</span>
  <span id="reportAuthor">Jon Doe</span>
  <br />
  <span>Updated:</span>
  <span id="reportUpdated">%s</span>
</div>%s""" % (_header, now, _footer)
       
    @cherrypy.expose
    def fetch_report(self):
        now = datetime.datetime.now().strftime("%d %b. %Y, %H:%M:%S")
        cherrypy.response.headers['Content-Type'] = 'application/json'
        return simplejson.dumps({'name': 'Music report (Ajax)',
                                 'author': 'Jon Doe',
                                 'updated': now})

if __name__ == '__main__':
    cherrypy.config.update({'server.socket_port': 8080})
    current_dir = os.path.abspath(os.path.dirname(__file__))
    conf = {'/test': {'tools.staticdir.on': True,
                      'tools.staticdir.dir': "test",
                      'tools.staticdir.root': current_dir},
            '/MochiKit': {'tools.staticdir.on': True,
                          'tools.staticdir.dir': "MochiKit",
                          'tools.staticdir.root': current_dir},
            '/selenium': {'tools.staticdir.on': True,
                          'tools.staticdir.dir': "selenium",
                          'tools.staticdir.root': current_dir}}
    cherrypy.quickstart(Dummy(), config=conf)
