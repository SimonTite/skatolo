import unittest
from dummy import Dummy


class DummyTest(unittest.TestCase):
    def test_00_construct(self):
        self.assertRaises(ValueError, Dummy, start=34)

    def test_01_forward(self):
        dummy = Dummy(right_boundary=3)
        self.assertEqual(dummy.forward(), 1)
        self.assertEqual(dummy.forward(), 2)
        self.assertEqual(dummy.forward(), 3)
        self.assertRaises(ValueError, dummy.forward)

    def test_02_backward(self):
        dummy = Dummy(left_boundary=-3, allow_negative=True)
        self.assertEqual(dummy.backward(), -1)
        self.assertEqual(dummy.backward(), -2)
        self.assertEqual(dummy.backward(), -3)
        self.assertRaises(ValueError, dummy.backward)

    def test_03_boundaries(self):
        dummy = Dummy(right_boundary=3, left_boundary=-3,
                      allow_negative=True)
        self.assertEqual(dummy.backward(), -1)
        self.assertEqual(dummy.backward(), -2)
        self.assertEqual(dummy.forward(), -1)
        self.assertEqual(dummy.backward(), -2)
        self.assertEqual(dummy.backward(), -3)
        self.assertRaises(ValueError, dummy.backward)
        self.assertEqual(dummy.forward(), -2)
        self.assertEqual(dummy.forward(), -1)
        self.assertEqual(dummy.forward(), 0)
        self.assertEqual(dummy.backward(), -1)
        self.assertEqual(dummy.forward(), 0)
        self.assertEqual(dummy.forward(), 1)
        self.assertEqual(dummy.forward(), 2)

if __name__ == '__main__':
    suite = unittest.TestSuite((DummyTest, ))
    unittest.main(testRunner=unittest.TextTestRunner(verbosity=2))
